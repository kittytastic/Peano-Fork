// This file is part of the Peano project. For conditions of distribution and
// use, please see the copyright notice at www.peano-framework.org
#ifndef _PEANO_STACKS_STACKS_H_
#define _PEANO_STACKS_STACKS_H_

namespace peano {
    namespace stacks {
      class Constants;
    }
}


class peano::stacks::Constants {
  public:
	static const int InOutStack;
};


#endif
