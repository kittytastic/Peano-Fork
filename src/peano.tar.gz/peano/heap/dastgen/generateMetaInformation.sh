java -jar ../../../../../peprot/lib/DaStGen.jar --plugin PeanoSnippetGenerator --naming PeanoNameTranslator MetaInformation.def ../records/
