// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast;

import jargs.gnu.CmdLineParser;
import jargs.gnu.CmdLineParser.Option;

import java.util.LinkedList;
import java.util.Set;
import java.util.Vector;

import de.tum.in.dast.generator.CodeWriter;
import de.tum.in.dast.generator.DaStConfiguration;
import de.tum.in.dast.generator.Validator;
import de.tum.in.dast.generator.DastGenAST.CompilationUnit;
import de.tum.in.dast.generator.DastGenAST.DaStGenASTBuilder;
import de.tum.in.dast.generator.DastGenAST.DaStGenASTPrinter;
import de.tum.in.dast.generator.conditionset.Conditional;
import de.tum.in.dast.generator.conditionset.ConditionsSelector;
import de.tum.in.dast.generator.mapper.MapperFactory;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.generator.plugin.CodePluginFactory;
import de.tum.in.dast.node.Start;
import de.tum.in.dast.properties.DaStProperties;
import de.tum.in.dast.util.DaStStringBuilder;
import de.tum.in.dast.util.Printer;
import de.tum.in.dast.util.TreeReader;

/**
 * This is the main-class of DastGen. 
 *
 * TODO: - move more settings to DaStConfiguration
 *       - move checking of consistency to DaStConfiguration
 *       - all commandline arguments could be passed to the configuration
 *         object and be processed there.
 *
 * @author Wolfgang Eckhardt
 * 
 */
public class DaStGen {
	
	private static DaStProperties properties = new DaStProperties("DaStGen.properties");
	// indicates if the sabbleCC-tree should be printed
	private static boolean printTree = false;
	// indicates if the input should be validated
	private static boolean validate = true;
	// indicates if the output should be generated
	private static boolean generateCode = true;
	
	private static boolean runQuiet = true;
	
	
	public static void main(String[] args) {
		
		try {
			initialize(args);
			DaStConfiguration configuration = DaStConfiguration.getConfiguration();
			
			LinkedList<Start> trees = parseTree(configuration.getSource(), configuration.getSearchPaths() );
			Set<Set<Conditional>> conditions = getConditionSet(trees);

			if (printTree) {
				printSableCCTrees(trees);
				printDaStGenTrees(trees);
			}

			if (validate) {
				validate(trees, conditions);
			}

			if (generateCode) {
				if (configuration.getTarget() == null) {
					System.out.println("Please specify a target directory!");
					System.out.println("Use option -h to display help message.");
					System.exit(-1);
				}
				generateCode(trees, conditions, configuration.getTarget());			
			}
		} catch (Exception e) {
			System.out.println(e.getClass() + " "+e.getMessage()+"\n");
			e.printStackTrace();
			System.out.println("Use option -h to display help message.");
		}
	}
	
	/**
	 * parses a given file and creates the abstract syntax tree
	 * 
	 * @param path the path of the file to parse
	 * @return the abstract syntax trees, created from the file and files extended
	 * @throws Exception is thrown, if the file can't be found or 
	 * 						if an error during parsing a file is found  
	 */
	private static LinkedList<Start> parseTree(String path, Vector<String> searchPaths) throws Exception   {
		TreeReader reader = new TreeReader(path,searchPaths, runQuiet);
		LinkedList<Start> result = reader.readTrees();
		return result;
	}

	
	private static Set<Set<Conditional>> getConditionSet(LinkedList<Start> trees) {
		ConditionsSelector conditionsSelector = new ConditionsSelector();
		for (Start ast: trees) {
			ast.apply(conditionsSelector);
		}	
		return conditionsSelector.getPowerSetOfConditions();
	}
	
	/**
	 * prints the sableCC-Tree to standard out
	 * @param ast the tree to print
	 */
	private static void printSableCCTrees(LinkedList<Start> trees) {
		for (Start ast: trees) {
			ast.apply(new Printer());
		}
	}
	
	/**
	 * prints the trees which DaStGen builds internally to standard out
	 * @param ast the tree to print
	 */
	private static void printDaStGenTrees(LinkedList<Start> trees) {
		System.out.println("\nPrinting DaStGen-Tree...\n");
		CompilationUnit unit = DaStGenASTBuilder.buildDaStGenAST(trees, getConditionSet(trees));
		DaStGenASTPrinter printer = new DaStGenASTPrinter();
		unit.applyVisitor(printer);
	}
	
	/**
	 * validates the abstract syntax tree, i.e. a semantic analysis
	 * @param ast the syntax tree to validate
	 */
	private static void validate(LinkedList<Start> trees, Set<Set<Conditional>> conditions) {
		try {
			for (Set<Conditional> p: conditions) {
				Validator val = new Validator(p);
				val.validate(trees);
			}
		} catch (RuntimeException re) {
			System.err.println("\nValidation failed!\n "+re.getMessage());
			System.exit(-1);
		}
		
		if (!runQuiet) {
    	System.out.println("*** validation successful");
		}
	}
	
	/**
	 * generate the code and print it to standard out
	 * @param ast the tree to print 
	 * @param destination destination directory for code creation
	 */
	private static void generateCode(LinkedList<Start> trees, Set<Set<Conditional>> conditions, String destination) {
		new CodeWriter(trees, conditions, runQuiet).writeCode(destination);
	}
	
	/**
	 * print the usage
	 */
	private static void usage() {
		if (properties != null) {
			System.out.println(properties.getProperty("usage"));
			System.out.println();
		} else {
			System.out.println("In method usage(): properties is null! ");
		}
	}
	
	/**
	 * parses the commandline-arguments and initializes DaStGen with 
	 * the values read from the arguments, or with default values.
	 * 
	 * @param args the commandline arguments
	 */
	@SuppressWarnings("unchecked")
	private static void initialize(String args[]) {
		
		CmdLineParser parser = new CmdLineParser();
		Option indent = parser.addIntegerOption('i', "indent");
		Option print = parser.addBooleanOption('p', "print");
		Option validating = parser.addBooleanOption('v', "validate");
		Option code = parser.addBooleanOption('c', "generate");
		Option naming = parser.addStringOption('n', "naming");
		Option plugin = parser.addStringOption("plugin");
		Option help = parser.addBooleanOption('h',"help");
		Option pragmas = parser.addBooleanOption("pragmas");
		Option manualAlign   = parser.addBooleanOption("align");
		Option manualInline  = parser.addBooleanOption("inline");
		Option packedDoubles = parser.addBooleanOption("packed-doubles");
		Option searchPath = parser.addStringOption('I', "include");
		Option quiet      = parser.addBooleanOption( 'q', "quiet" );
		
		try {
			parser.parse(args);
		}
		catch ( CmdLineParser.OptionException e ) {
			System.err.println(e.getMessage());
			usage();
			System.exit(-1);
		}
	        
		if ((Boolean)parser.getOptionValue(help, false)) {
			usage();
			System.exit(0);
		}
		
        runQuiet = (Boolean) parser.getOptionValue(quiet, false);

		int indentWidth = (Integer) parser.getOptionValue(indent, new Integer(3));
		DaStStringBuilder.setIndentWidth(indentWidth);
				
		String namingStrategy = (String) parser.getOptionValue(naming, "SimpleNameTranslator");
		setNameTranslator(namingStrategy);
		Vector<String> codePlugins = (Vector<String>) parser.getOptionValues(plugin);
		CodePluginFactory.setPlugins(codePlugins,runQuiet);
		
		DaStConfiguration.generatePragmas  = (Boolean) parser.getOptionValue(pragmas, false);
		DaStConfiguration.manuallyAlign    = (Boolean) parser.getOptionValue(manualAlign, false);
        DaStConfiguration.manuallyInline   = (Boolean) parser.getOptionValue(manualInline, false);
		MapperFactory.supportPackedDoubles = ((Boolean) parser.getOptionValue(packedDoubles, false));
		
		boolean p = (Boolean) parser.getOptionValue(print, false);
		boolean v = (Boolean) parser.getOptionValue(validating, false);
		boolean c = (Boolean) parser.getOptionValue(code, false);
		
		if (p || v || c) {
			// if one of these is specified on the commandLine (i.e. true),
			// set the values
			printTree = p;
			validate = v;
			generateCode = c;
		}
		
		Vector<String> searchPaths = new Vector<String>();
		// parser is a state machine, i.e. we may not ask for value multiple times
		// I thus store it within arg
		Object arg = parser.getOptionValue(searchPath);
		if (arg!=null) {
          //System.err.println( "*** arg=" + arg );
          try {
            for (String x: ( (String)arg ).split(":")) {
	  	  	  System.err.println( "*** add " + x + " to search directories");
		      searchPaths.add(x);
		    }
          }
          catch (java.lang.NullPointerException exc) {
        	System.err.println( "*** ERROR Null pointer exception due to " + arg );
          }
		}

		String[] remaining = parser.getRemainingArgs();
		String source = null;
		String target = null;
		if (remaining.length > 0) {
			source = remaining[0];
		} else {
			// DaStGen was started without sourcefile
			usage();
			System.exit(-1);
		}
		
		if (remaining.length > 1) {
			target = remaining[1];
		}
		
		DaStConfiguration.initialize(source, target, searchPaths);
		
		if (!runQuiet) {
		  System.out.println("\n*** Running with Parameters:\n*** indent "+indentWidth+
				" source "+source+" target "+target + "\n*** naming: "+namingStrategy +
				(codePlugins.isEmpty() ? "" : " codeplugin: "+ codePlugins ) +
				"\n*** printTree: "+printTree+" validate: "+validate+" generateCode: "+generateCode+"\n" +
						"*** packed-doubles: "+ MapperFactory.supportPackedDoubles + "\n\n");
		}
	}
	
	
	private static void setNameTranslator(String nameTranslator) {
		try {
			NameTranslatorFactory.setNameTranslator(nameTranslator);
		} catch (Exception e) {
			System.out.println("XXX Error: NameTranslator "+nameTranslator+" not available!");
			System.exit(-1);
		}
		
	}
	
}
