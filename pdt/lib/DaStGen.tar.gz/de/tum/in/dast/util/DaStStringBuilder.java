// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.util;

// TODO introduce methods: appendIncrementAndIndent; appendDecrementAndIndent;

/**
 * Wrapper for a java.lang.StringBuilder. 
 * Adds the functionality indent new lines automatically.
 * 
 * @author Wolfgang Eckhardt
 */
public class DaStStringBuilder { 

	/**
	 * the whitespaces to append; It is static, because it should be 
	 * the same for all DaStStringBuilders within DaStGen. 
	 */
	private static String whiteSpace = "   ";
	
	/**
	 * the wrapped StringBuilder. All method-calls of the implemented 
	 * interfaces are delegated to it.
	 */
	private StringBuilder stringBuilder;
	
	/**
	 * The indent level
	 */
	private int indentLevel = 0;
	
	/**
	 * Only for validation
	 */
	private java.util.Stack<String> indentStack;
	
	/**
	 * Constructor for DaStStringBuilder. Instantiates the wrapped StringBuilder
	 * by calling its default constructor. As of java version 1.6, the default 
	 * capacity of a StringBuilder is 16 characters.
	 */
	public DaStStringBuilder() {
		stringBuilder = new StringBuilder();
		indentStack   = new java.util.Stack<String>();
	}
	
	/**
	 * Instantiates the wrapped StringBuilder with the capacity.
	 * 
	 * @param capacity the initial capacity the wrapped StringBuilder should have.
	 */
	public DaStStringBuilder(int capacity) {
		stringBuilder = new StringBuilder(capacity);
		indentStack   = new java.util.Stack<String>();
	}
	
	/**
	 * Instantiates the wrapped StringBuilder with the value of seq set.
	 * 
	 * @param seq the CharSequence, the wrapped StringBuilder is initialized with.
	 */
	public DaStStringBuilder(CharSequence seq) {
		stringBuilder = new StringBuilder(seq);
		indentStack   = new java.util.Stack<String>();
	}
	
	/**
	 * set the indent width, i.e. the number of whitespaces, which should be
	 * indented per indent level.
	 * 
	 * @param newWidth
	 */
	public static void setIndentWidth(int newWidth) {
		whiteSpace = "";
		for (int i = 0; i < newWidth; i++) {
			whiteSpace += " ";
		}
	}
	
	/**
	 * Appends a newLine to the StringBuilder and appends the 
	 * number of whitespaces determined by indentWidth and the 
	 * indentLevel
	 */
	public void indent() {
		indent(1);
	}
	
	/**
	 * Appends the specified number of newLines to the StringBuilder and appends the 
	 * number of whitespaces determined by indentWidth and the 
	 * indentLevel
	 * 
	 * @param numberNewLines the number of new lines
	 */
	public void indent(int numberNewLines) {
		for (int i = 0; i < numberNewLines; i++) {
			stringBuilder.append("\n");
			for (int j = 0; j < indentLevel; j++) {
				stringBuilder.append(whiteSpace);
			}
		}
	}
	
	/**
	 * increases the indent by one.
	 */
	public void incrementIndentLevel(String methodTrace) {
		indentLevel++;
		indentStack.push(methodTrace);
	}
	
	/**
	 * Increments the indentLevel by 1 and indents.
	 */
	public void incrementAndIndent(String methodTrace) {
		indentLevel++;
		indentStack.push(methodTrace);
		indent();
	}
	
	/**
	 * decreases the indent by one.
	 */
	public void decrementIndentLevel(String methodTrace) {
		indentLevel--;
		if (indentStack.empty()) {
			System.err.println( "ERROR: no indent found for " + methodTrace );
		}
		else {
  		  String topStackElement = indentStack.pop();
  		  if (!topStackElement.equals(methodTrace)) {
			System.err.println( "ERROR: expected " + topStackElement + " but got " + methodTrace );
			for (String el: indentStack) {
         		System.err.println( "- stack element: " + el );
			}
		  }
		}
		if (indentLevel < 0) {
          for (StackTraceElement ste : Thread.currentThread().getStackTrace()) {
            System.out.println(ste);
          }
          indentLevel = 0;
		}
	}
	

	/**
	 * Decrements the indentLevel by 1 and indents.
	 */
	public void decrementAndIndent(String methodTrace) {
		indentLevel--;
		if (indentStack.empty()) {
			System.err.println( "ERROR: no indent found for " + methodTrace );
		}
		else {
    		String topStackElement = indentStack.pop();
		  if (!topStackElement.equals(methodTrace)) {
			  System.err.println( "ERROR: expected " + topStackElement + " but got " + methodTrace );
				for (String el: indentStack) {
	         		System.err.println( "- stack element: " + el );
				}
		  }
		}
		if (indentLevel < 0) {
          for (StackTraceElement ste : Thread.currentThread().getStackTrace()) {
            System.out.println(ste);
          }
		  indentLevel = 0;
		}
		indent();
	}
	
	
	/**
	 * Appends the CharSequence seq to the buffer.
	 * 
	 * @param seq - The character sequence to append. If csq is null, 
	 * then the four characters "null" are appended to this Appendable.
	 */
	public void append(CharSequence seq) {
		stringBuilder.append(seq);
	}
	
	/**
	 * Appends the CharSequence seq to the buffer and calls indent(1) afterwards.
	 * 
	 * @param seq - The character sequence to append. If csq is null, 
	 * then the four characters "null" are appended to this Appendable.
	 */
	public void appendAndIndent(CharSequence seq) {
		stringBuilder.append(seq);
		indent(1);
	}


	
	/**
	 *  Returns the length (character count).
     *
     * @return the length of the sequence of characters currently represented 
     * by this object
	 */
	public int length() {
		return stringBuilder.length();
	}


    /**
     * Returns a string representing the data in this sequence. A new String 
     * object is allocated and initialized to contain the character sequence 
     * currently represented by this object. This String is then returned. 
     * Subsequent changes to this sequence do not affect the contents of the String.
     * 
     * @return a string representation of this sequence of characters.
     */
	@Override
	public String toString() {
		return stringBuilder.toString();
	}

}
