// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.util;

import de.tum.in.dast.analysis.DepthFirstAdapter;
import de.tum.in.dast.node.Node;
import de.tum.in.dast.node.Token;

/**
 * Utility-class, which prints a SabbleCC-tree to System.out
 * 
 * @author Wolfgang Eckhardt
 *
 */
public class Printer extends DepthFirstAdapter {

	int indent = 0;

	  void indent(){
	    String s = new String ("");
	    for(int i=0; i < indent; i++) s += "   "; 
	    System.out.print(s);
	  }
	    
	  public void defaultIn(Node node) {
	    indent();
	    System.out.println(node.getClass().getName().substring("de.tum.in.dast.node".length()+1));
	    indent++;
	  }
	  
	  public void defaultOut(Node node) {
	    indent--;
	  }
	  
	  public void defaultCase(Node node) {
	    indent();
	    System.out.println(node.getClass().getName().substring("de.tum.in.dast.node".length()+1)+": " + ((Token) node).getText());
	  }
	
}
