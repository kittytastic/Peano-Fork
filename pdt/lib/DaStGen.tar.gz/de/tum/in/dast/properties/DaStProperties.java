// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.properties;

import java.io.IOException;
import java.util.Properties;

/**
 * This class offers simpler access to java property files.
 * A property file represents key/value-pairs, separated by "=".
 * So a valid line looks just like
 * 
 * key = value
 * 
 * The usage of this class is to create an instance, loading the 
 * properties file given in the constructor. Then, just use the method
 * String getProperty(String property) specified by java.util.Properties
 * to retrieve the value for a key.
 *  
 * @author Wolfgang Eckhardt
 *
 */
public class DaStProperties extends Properties {

	private static final long serialVersionUID = 3699341627741298457L;

	/**
	 * Construct a properties class for a file. The IOException is swallowed, in case
	 * it is caught, an error message is printed. The object is created anyway, and is 
	 * usable in terms that you should be able to call all methods offered. In particular,
	 * getProperty() returns null, if a property is not found, or reading the properties file
	 * was not successful. 
	 * 
	 * @param propertyFileName the filename of the properties-file to load. The filename 
	 * 		  has to be relative to this class. 
	 */
	public DaStProperties(String propertyFileName) {
		try {
			load(DaStProperties.class.getResourceAsStream(propertyFileName));
		} catch (IOException ioe) {
			System.err.println("XXX");
			System.err.println("XXX Error: could not open property file "+propertyFileName);
			System.err.println("XXX");
		}
	}
}
