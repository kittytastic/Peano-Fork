// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

import java.util.ArrayList;

public class Enumeration extends Type implements AbstractNode {

	private ArrayList<String> values = new ArrayList<String>();
	
	
	public Enumeration(String typeName, String qualification) {
		super(typeName, qualification);
	}
	
	public void applyVisitor(Visitor visitor) {
		visitor.process(this);
	}
	
	public void addValue(String value) {
		values.add(value);
	}

	public ArrayList<String> getValues() {
		return values;
	}

	public int numberOfValues() {
		return values.size();
	}
	
}
