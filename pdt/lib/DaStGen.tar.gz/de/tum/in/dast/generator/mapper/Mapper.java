// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.mapper;

import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.util.DaStStringBuilder;

/**
 * Interface for Mappers, which map members to datatypes and create the
 * corresponding get-, set- and toStringmethods. Additionally, they
 * determin the datatype the member is mapped to, and the length of 
 * bits if the member is packed.
 * 
 * @author Wolfgang Eckhardt, Tobias Weinzierl
 */
public interface Mapper {

	public static final String AttributeInline = "\n #ifdef UseManualInlining\n __attribute__((always_inline))\n #endif \n";

  /**
	 * How many getter/setter and whatever are to be created?
	 * 
	 * @return
	 */
	public int getNumberOfOperations(); 
	
	/**
	 * create the method signature of the specified method for the member
	 */
	public void writeMethodSignature(int operationNumber, DaStStringBuilder builder);
	
	/**
	 * write the method implementation for the specified operation
	 */
	public void writeMethodImplementation(int operationNumber, DaStStringBuilder builder);
	
	/**
	 * write the declaration of the corresponding member to the DaStStringBuilder
	 */
	public void writeDeclaration(DaStStringBuilder builder, boolean currentClassIsPacked);
	
	/**
	 * @return the datatype, the member is mapped to.
	 * This may be the type, as which the member was declared, 
	 * or something like vector or blitz::tiny-vector
	 */
	public String getMappedDataType();
	
	/**
	 * create the toString-Method (as well signature as body)
	 */
	public String getToString();

	/**
	 * @return the length of the bitfield the member needs if 
	 * 			it is stored compressed.
	 */
	public Size getBitfieldLength();
	
	/**
	 * @return the type object, describing the data type of the 
	 *         member closely.
	 */
	public Type getTypeObject();
	
	/**
	 * write assertions which have to be checked at construction time of a data
	 * structure, e.g. that the packed-type is sufficient wide.
	 */
	public void writeConstructorAssertions(DaStStringBuilder builder);
	
}
