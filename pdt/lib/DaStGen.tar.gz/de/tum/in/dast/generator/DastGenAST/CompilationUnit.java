// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 * 
 * Represents a compilation unit. Heart piece of the unit 
 * are two classes: a packed class, containing packed data (if specified 
 * for some fields), and a unpacked class.
 * 
 * @author Wolfgang Eckhardt
 */
public class CompilationUnit implements AbstractNode, AbstractNodeContainer {
	
	private LinkedList<AbstractNode> childNodes = new LinkedList<AbstractNode>();
	
	private String name = "";
	
	private String namespace = "";


	public void applyVisitor(Visitor visitor) {
		visitor.process(this);
	}
	
	public void addChildNodeEnd(AbstractNode node) {
		childNodes.add(node);
	}
	
	public void addChildNodeFront(AbstractNode node) {
		childNodes.addFirst(node);
	}

	public LinkedList<AbstractNode> getChildNodes() {
		return childNodes;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}
}
