// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.mapper;

import de.tum.in.dast.generator.DaStConfiguration;
import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.memberSelection.PackedMember;
import de.tum.in.dast.generator.naming.NameTranslator;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.util.DaStStringBuilder;

/**
 * Extends an ArrayMapper for packed boolean arrays. 
 * 
 * @author Wolfgang Eckhardt
 *
 */
public class PackedBitSetMapper extends BitsetMapper {

	private NameTranslator translator = NameTranslatorFactory.getNameTranslator();
	
	private String fieldLength = null;
	
	public PackedBitSetMapper(PackedMember member, String bitsetLength) {
		super(member);
		fieldLength = bitsetLength;
	}
	
	@Override
	protected void writeFlipOperationImplementation(DaStStringBuilder builder) {
      String mappedPackedVariable   = ((PackedMember)member).getMappedVariable();

	  builder.indent();
      writeFlipOperationSignature(!DaStConfiguration.manuallyInline,builder);
      builder.append( " {" );
      builder.incrementAndIndent(getClass().getName());
      writeElementAccessAssertions(builder);

      String packedType = ((PackedMember)member).getBitFieldType();

      builder.appendAndIndent( packedType + " mask = 1 << (" + ((PackedMember)member).getStartIndex() + ");" );
      builder.appendAndIndent( "mask = mask << elementIndex;" );
      builder.append( mappedPackedVariable + "^= mask;" );
      
      builder.decrementAndIndent(getClass().getName());
      builder.appendAndIndent("}");
	}
	
	@Override
	protected void getSetElementMethodBody(DaStStringBuilder builder) {
      String mappedPackedVariable   = ((PackedMember)member).getMappedVariable();
      String argumentName           = translator.getArgumentName(member.getMemberName());
      String packedType             = ((PackedMember)member).getBitFieldType();
			
	  writeElementAccessAssertions(builder);

      builder.append         ( translator.getAssertion() );
      builder.appendAndIndent( "(!"+argumentName+" || "+argumentName+"==1);" );
      builder.appendAndIndent( "int shift        = " + ((PackedMember)member).getStartIndex() + " + elementIndex; " );  
      builder.appendAndIndent( packedType + " mask         = 1     << (shift);" );
      builder.appendAndIndent( packedType + " shiftedValue = "+argumentName+" << (shift);" );
      builder.appendAndIndent( mappedPackedVariable + " = " + mappedPackedVariable + " & ~mask;" );
      builder.append         ( mappedPackedVariable + " = " + mappedPackedVariable + " |  shiftedValue;" );
	}

	@Override
	protected void getGetElementMethodBody(DaStStringBuilder builder) {
      String mappedPackedVariable   = ((PackedMember)member).getMappedVariable();
			
	  writeElementAccessAssertions(builder);
      builder.appendAndIndent( "int mask = 1 << (" + ((PackedMember)member).getStartIndex() + ");" );
      builder.appendAndIndent( "mask = mask << elementIndex;" );
      builder.append         ( "return (" + mappedPackedVariable + "& mask);");
	}
	
	
	
    @Override
	protected void getGetMethodBody(DaStStringBuilder builder) {
		
		// long mask = 2 ^ n - 1;
		// mask << member.getStart();
		// int tmp = mappedVar & mask;
		// tmp >> member.getStart();
		// std::bitset result = tmp;
		// return result; 
		
		String packedType = ((PackedMember)member).getBitFieldType();
		
		builder.appendAndIndent(packedType + " mask = "+"("+packedType+") (1 << ("+fieldLength+")) - 1 ;");
		builder.appendAndIndent("mask = " + ((PackedMember)member).getBitFieldCast() + "(mask << ("+((PackedMember)member).getStartIndex()+"));");
		
		builder.appendAndIndent(packedType + " tmp = " + ((PackedMember)member).getBitFieldCast() + "(" + member.getMappedVariable() +" & mask);");
			
		builder.appendAndIndent("tmp = " + ((PackedMember)member).getBitFieldCast() + "(tmp >> ("+ ((PackedMember)member).getStartIndex() +"));");
		builder.appendAndIndent(type.getTypeString(false)+" result = tmp;");
		builder.append         ("return result;");
	}
	
    @Override
	protected void getSetMethodBody(DaStStringBuilder builder) {
		
		// long mask = 2 ^ n - 1;
		// mask << member.getStart();
		// mappedVar = mappedVar & ~mask;
		// mappedVar = mappedVar |arg0.to_ulong() << member.getStart();
		
		builder.appendAndIndent(((PackedMember)member).getBitFieldType()+" mask = "+
						"("+((PackedMember)member).getBitFieldType()+") (1 << ("+fieldLength+")) - 1 ;");
		String mappedVariable = ((PackedMember)member).getMappedVariable();
		builder.appendAndIndent("mask = " + ((PackedMember)member).getBitFieldCast() + "(mask << ("+((PackedMember)member).getStartIndex()+"));");
		builder.appendAndIndent(mappedVariable+" = " + ((PackedMember)member).getBitFieldCast() + "(" + mappedVariable + " & ~mask);");
		builder.append(mappedVariable + " = " +	((PackedMember)member).getBitFieldCast() + "(" + mappedVariable + " | "+translator.getArgumentName(member.getMemberName())+".to_ulong() << ("
					+ ((PackedMember)member).getStartIndex() + "));");
	}
	
	public Size getBitfieldLength() {
		return member.getArraySize();
	}

}
