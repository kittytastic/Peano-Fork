// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.naming;

/**
 * Factory class for NameTranslators.
 * Implementing the xxxclass of the Strategy-designpattern.
 *
 * @author Wolfgang Eckhardt
 */
public class NameTranslatorFactory {
	
	/**
	 * The current translator which is to translate names according
	 * to certain naming conventions.
	 */
	private static NameTranslator translator = new SimpleNameTranslator();
	
	/**
	 * set the strategy, which will be used for nametranslation.
	 * 
	 * @param strategy name of the strategy to use.
	 * 			valid values are: 
	 */
	public static void setNameTranslator(String strategy) throws Exception {
				translator = (NameTranslator) Class.forName(NameTranslatorFactory.class.getPackage().getName() 
						+ "."+strategy).newInstance();
	}
	
	/**
	 * @return the nameTranslator depending on the strategy which 
	 * 				was set before. If no strategy was chosen before,
	 * 				an instance of SimpleNameTranslator will be returned.
	 */
	public static NameTranslator getNameTranslator() {
		return translator;
	}

}
