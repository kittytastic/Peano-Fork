// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.naming;

public class PeanoHyphenNameTranslator extends PeanoNameTranslator {

	public String getIncludePath(String qualifiedClassName) {
		  
		String include;
		if (qualifiedClassName.contains("::")) {
			include = "";
			while (qualifiedClassName.indexOf(":")!=-1) {
			  String newSubstring = qualifiedClassName.substring(0, qualifiedClassName.indexOf(":")); 
			  qualifiedClassName  = qualifiedClassName.substring(qualifiedClassName.indexOf(":")+2);
              if ( !newSubstring.equals("peano") ) {
				include += newSubstring;
  				include += "/";
              }
            }
			include += "records/";
			include += qualifiedClassName.substring(qualifiedClassName.lastIndexOf(":") + 1);
		} else {
			include = qualifiedClassName;
		}
		
		include = correctHyphenation(include);
		
		return include + ".h";
	} 
	
	private String correctHyphenation(String includePath) {
		includePath = includePath.replaceAll("latticeboltzmann", "lattice-boltzmann");
		includePath = includePath.replaceAll("peanoiterator", "peano-iterator");
		includePath = includePath.replaceAll("contiequation", "conti-equation");
		includePath = includePath.replaceAll("heatequation", "heat-equation");
		includePath = includePath.replaceAll("staggeredpoisson", "staggered-poisson");
		includePath = includePath.replaceAll("shallowwater", "shallow-water");
		
		return includePath;
	}
	
}
