// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import de.tum.in.dast.generator.ConditionalDepthFirstAdapter;
import de.tum.in.dast.generator.DaStConfiguration;
import de.tum.in.dast.generator.conditionset.Conditional;
import de.tum.in.dast.generator.mapper.Mapper;
import de.tum.in.dast.generator.mapper.MapperFactory;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.memberSelection.PackedMember;
import de.tum.in.dast.generator.naming.NameTranslator;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.generator.packing.Packer;
import de.tum.in.dast.generator.packing.PackerFactory;
import de.tum.in.dast.node.AArrayDeclarator;
import de.tum.in.dast.node.AClassname;
import de.tum.in.dast.node.AConstantArrayDimension;
import de.tum.in.dast.node.ADecimalConstMemberDeclaration;
import de.tum.in.dast.node.AEnumDeclaration;
import de.tum.in.dast.node.AEnumerator;
import de.tum.in.dast.node.AExposeModifier;
import de.tum.in.dast.node.AFloatingConstMemberDeclaration;
import de.tum.in.dast.node.AFriendDeclaration;
import de.tum.in.dast.node.AIdentifierDeclarator;
import de.tum.in.dast.node.AIncludeStatement;
import de.tum.in.dast.node.AMemberDeclaration;
import de.tum.in.dast.node.ANamespace;
import de.tum.in.dast.node.AParamArrayDimension;
import de.tum.in.dast.node.ASignedBegin;
import de.tum.in.dast.node.ASignedDecimalConstMemberDeclaration;
import de.tum.in.dast.node.ASignedEnd;
import de.tum.in.dast.node.AUnsignedBegin;
import de.tum.in.dast.node.AUnsignedEnd;
import de.tum.in.dast.node.Start;
import de.tum.in.dast.node.TPacked;
import de.tum.in.dast.node.TParallel;
import de.tum.in.dast.node.TPersistent;
import de.tum.in.dast.util.RangeCalculator;
import de.tum.in.dast.util.SetUtils;

/**
 * This class builds the DaStGenAST from the Abstract Syntax Tree, which SableCC generates.
 * All the children of this object can be visited by a visitor.
 * 
 * @author Wolfgang Eckhardt
 */
public class DaStGenASTBuilder extends ConditionalDepthFirstAdapter {

	private NameTranslator translator = NameTranslatorFactory.getNameTranslator();
	
	private Enumeration enumeration;
	
	private ConstantMember constantMember;
	
	// the className, which was read as last 
	private StringBuilder classnameRead = new StringBuilder();
	
	private String classname;
	private String namespace;
	
	private Class packedClass = new Class();
	
	private Class unpackedClass = new Class();
	
	private CompilationUnit toplevelElement;
	
	private AbstractNodeContainer parentElement;
	
	private boolean firstPass = false;
	
	private boolean firstTree = true;
	
	// indicating if this member is persistent
	private boolean persistentDeclarationFound = false;
	// indicating if this member is packed
	private boolean packedDeclarationFound = false;
	// indicating if this member is parallelized
	private boolean parallelizeDeclarationFound = false;
	// indicating if this member is exposed
	private boolean exposeDeclarationFound = false;
	// the name of the member 
	private String memberName;
	// holds the arraylength, if the member found is an array
	private Size arraySize = null;
	// holds the start, if the range of values of this member is limited
	private int start;
	// holds the start, if the range of values of this member is limited
	private int end;
	// holds the name of the Members in the order in which they have been declared
	private ArrayList<String> orderOfElements = new ArrayList<String>();
	
	private Map<String, Size> ConstantSizes = new TreeMap<String, Size>();
	
	// holds the type of the bitfield for packed Members
	private Type packedFieldType;
	
	public static final String FIELD_PERSISTENT_RECORDS = "_persistent_records";

	
	public static CompilationUnit buildDaStGenAST(LinkedList<Start> trees, Set<Set<Conditional>> conditions) {
		
		CompilationUnit unit = new CompilationUnit();
		
		Iterator<Set<Conditional>> it = conditions.iterator();
		Set<Conditional> currentConditions = it.next();		
		DaStGenASTBuilder builder;
		
		Ifdef innerCondition = new Ifdef(currentConditions);
		if (it.hasNext()) {
			builder = new DaStGenASTBuilder(currentConditions, unit, innerCondition, true);
			builder.build(trees);
			unit.addChildNodeEnd(innerCondition);
		} else {
			builder = new DaStGenASTBuilder(currentConditions, unit, unit, true);
			builder.build(trees);
		}
		

		
		while (it.hasNext()) {
			currentConditions = it.next();
			IfdefBranch branch = new IfdefBranch(currentConditions);
			innerCondition.addChildNodeEnd(branch);
			builder = new DaStGenASTBuilder(currentConditions, unit, branch, false);
			builder.build(trees);
		}
		return unit;
	}
	
	
	public DaStGenASTBuilder(Set<Conditional> selectedConditions, CompilationUnit toplevelElement,
			AbstractNodeContainer parentElement, boolean firstPass) {
		super(selectedConditions);
		this.toplevelElement = toplevelElement;
		this.parentElement = parentElement;
		this.firstPass = firstPass;	
	}
	
	/**
	 * public only for testing purpose!
	 */
	public void build(List<Start> trees) {
		MetadataSelector msd = new MetadataSelector(selectedConditions);
		msd.selectMetadata(trees);
		this.classname = msd.getClassname();
		this.namespace = msd.getNameSpace();
		this.packedFieldType = msd.getPackedFieldType();
		this.ConstantSizes = msd.getConstantSizes();
		
		toplevelElement.setName(classname);
		toplevelElement.setNamespace(namespace);
		initializeClassObjects(); 
		
		orderOfElements = new ArrayList<String>();

		firstTree = false;
		for (int i = 0; i < trees.size() - 1; i++) {
			trees.get(i).apply(this);
		}
		firstTree = true;
		trees.get(trees.size() - 1).apply(this);
		
		parentElement.addChildNodeEnd(unpackedClass);
		parentElement.addChildNodeEnd(packedClass);
		
		postProcessBuilding();
	}
	
	private void initializeClassObjects() {
		String packedClassname = NameTranslatorFactory.getNameTranslator().getClassnameForPackedClass(classname);
		String flatClassname = NameTranslatorFactory.getNameTranslator().getClassnameForFlatClass(classname);
		packedClass.initialize(namespace, packedClassname, flatClassname, true);
		unpackedClass.initialize(namespace, flatClassname, packedClassname, false);
		
		Type packedClassType = new Type(packedClassname, namespace);
		Typedef typedef = new Typedef(packedClassType, "Packed");
		unpackedClass.addTypedef(typedef);
	}
	
	
	// public for testing purposes...
	private void postProcessBuilding() {
		Packer packer = PackerFactory.getPacker();
		List<Member> virtualMembers  = packedClass.getVirtualMembers();
		List<Member> internalMembers = packedClass.getInternalMembers();
		packer.pack(virtualMembers, internalMembers, packedFieldType);
		
		
		virtualMembers = packedClass.getStruct().getVirtualMembers();
		internalMembers = packedClass.getStruct().getInternalMembers();
		packer.pack(virtualMembers, internalMembers, packedFieldType);		
		
		unpackedClass.getInternalMembers().addAll(unpackedClass.getVirtualMembers());
		unpackedClass.getStruct().getInternalMembers().addAll(unpackedClass.getStruct().getVirtualMembers());

		packedClass.setNeedsPragmas(DaStConfiguration.generatePragmas);
		
		correctPersistentMembers(packedClass);
		correctPersistentMembers(unpackedClass);
		
		SetUtils.sort(packedClass.getVirtualMembers(), orderOfElements);
		SetUtils.sort(unpackedClass.getVirtualMembers(), orderOfElements);
	}
	
	
	/** generation of Includes */
	
	@Override
	public void inStart(Start start) {
		
		// generate default includes only once
		if (firstPass && firstTree) {
			String[] includes;
			
			includes = translator.getIncludes();
			if (includes != null) {
				for (int i = 0; i < includes.length; i++) {
					Include include = new Include(includes[i]);
					toplevelElement.addChildNodeFront(include);
				}
			}
			
		}
	}
	
	@Override
	public void outStart(Start start) {
		if (firstTree && firstPass) {
			NamespaceDeclaration nsDeclaration = new NamespaceDeclaration(namespace);
			nsDeclaration.addClassname(NameTranslatorFactory.getNameTranslator().getClassnameForFlatClass(classname));
			nsDeclaration.addClassname(NameTranslatorFactory.getNameTranslator().getClassnameForPackedClass(classname));
			toplevelElement.addChildNodeEnd(nsDeclaration);
		}
	}
	
	
	/** 
	 * - Set the classname for members of the struct PersistentRecords to 
	 *   OLD_CLASSNAME::PersistentRecords and update the mappedVariable;
	 * 
	 * - create members for all members of the struct PersistentRecords and
	 *   add them to the virtual members of the class.   
	 * 
	 */
	private void correctPersistentMembers(Class classObject) {
		String persistentRecordsName = NameTranslatorFactory.getNameTranslator().getPersistentRecords();
		String persistentRecordsFieldName = NameTranslatorFactory.getNameTranslator().getAttributeName(FIELD_PERSISTENT_RECORDS); 
		
		List<Member> persistentMembers = classObject.getStruct().getVirtualMembers();
		for (Member persistentMember: persistentMembers) {
			
			Member clone = persistentMember.clone();
			String mappedVariable = persistentRecordsFieldName + "." + clone.getMappedVariable();
			clone.setMappedVariable(mappedVariable);
			classObject.addMember(clone);
			
			String classname = persistentMember.getClassName() + "::" + persistentRecordsName; 
			persistentMember.setClassName(classname);
		}
	}
	
	@Override
	public void inAIncludeStatement(AIncludeStatement node) {
		
		if (firstPass) {		
			Include include = new Include("#include "+node.getIncludename().getText());
			toplevelElement.addChildNodeFront(include);
		}
	}
	
	/** generation of Classname and Namespace */	
	
	@Override
	public void inAClassname(AClassname node) {
		classnameRead = new StringBuilder();
	}
	
	@Override
	public void outAClassname(AClassname node) {
		classnameRead.append(node.getIdentifier().getText());
	}

	public void inANamespace(ANamespace node) {
		classnameRead.append(node.getIdentifier().getText()+"::");
	}
	
	/** friend declarations */
	
	public void outAFriendDeclaration(AFriendDeclaration node) {
		FriendDeclaration friend = new FriendDeclaration(classnameRead.toString());
		packedClass.addFriendDeclaration(friend);
		unpackedClass.addFriendDeclaration(friend);
	}
	
	/** Process declaration of enumerations  */
	
	public void inAEnumDeclaration(AEnumDeclaration node) {
		if ("".equals(unpackedClass.getNamespace())) {
			enumeration = new Enumeration(node.getIdentifier().getText(),
					unpackedClass.getClassname());
		} else {
			enumeration = new Enumeration(node.getIdentifier().getText(),
					unpackedClass.getNamespace()+"::" + unpackedClass.getClassname());
		}
	}
	
	public void outAEnumDeclaration(AEnumDeclaration node) {
		unpackedClass.addEnumeration(enumeration);
		Typedef typedef = new Typedef(enumeration, enumeration.getTypeString(false));
		packedClass.addEnumTypedef(typedef);
		enumeration = null;
	}

	public void inAEnumerator(AEnumerator node) {
		enumeration.addValue(node.getIdentifier().getText());
	}
	
	/** Process declaration of constant members */
	
	@Override
	public void inADecimalConstMemberDeclaration(ADecimalConstMemberDeclaration node)
    {
		if ("".equals(unpackedClass.getNamespace())) {
			constantMember = new ConstantMember(node.getIdentifier().getText(), 
					node.getTypeSpecifier().toString().trim(),
					node.getDecimalConstant().getText(),
					unpackedClass.getClassname());
		} else {
			constantMember = new ConstantMember(node.getIdentifier().getText(),
					node.getTypeSpecifier().toString().trim(),
					node.getDecimalConstant().getText(),
					unpackedClass.getNamespace()+"::" + unpackedClass.getClassname());
		}
    }

	@Override
    public void outADecimalConstMemberDeclaration(ADecimalConstMemberDeclaration node)
    {
		unpackedClass.addConstantMember(constantMember);
		constantMember = null;
    }
	
	@Override
	public void inASignedDecimalConstMemberDeclaration(ASignedDecimalConstMemberDeclaration node)
    {
		if ("".equals(unpackedClass.getNamespace())) {
			constantMember = new ConstantMember(node.getIdentifier().getText(), 
					node.getTypeSpecifier().toString().trim(),
					node.getSignedDecimalConstant().getText(),
					unpackedClass.getClassname());
		} else {
			constantMember = new ConstantMember(node.getIdentifier().getText(),
					node.getTypeSpecifier().toString().trim(),
					node.getSignedDecimalConstant().getText(),
					unpackedClass.getNamespace()+"::" + unpackedClass.getClassname());
		}
    }

	@Override
    public void outASignedDecimalConstMemberDeclaration(ASignedDecimalConstMemberDeclaration node)
    {
		unpackedClass.addConstantMember(constantMember);
		constantMember = null;
    }
	
	@Override
	public void inAFloatingConstMemberDeclaration(AFloatingConstMemberDeclaration node)
    {
		if ("".equals(unpackedClass.getNamespace())) {
			constantMember = new ConstantMember(node.getIdentifier().getText(), 
					node.getTypeSpecifier().toString().trim(),
					node.getFloatingConstant().getText(),
					unpackedClass.getClassname());
		} else {
			constantMember = new ConstantMember(node.getIdentifier().getText(),
					node.getTypeSpecifier().toString().trim(),
					node.getFloatingConstant().getText(),
					unpackedClass.getNamespace()+"::" + unpackedClass.getClassname());
		}
    }

	@Override
    public void outAFloatingConstMemberDeclaration(AFloatingConstMemberDeclaration node)
    {
		unpackedClass.addConstantMember(constantMember);
		constantMember = null;
    }
	
	/** Process member declarations **/
	
	@Override
	public void inAMemberDeclaration(AMemberDeclaration node) {
		persistentDeclarationFound  = false;
		packedDeclarationFound      = false;
		parallelizeDeclarationFound = false;
		exposeDeclarationFound      = false;
		arraySize = null;
		start = 0;
		end = 0;
	}

	@Override
	public void caseTPersistent(TPersistent node) {
		persistentDeclarationFound = true;
	}

  @Override
  public void caseAExposeModifier(AExposeModifier node) {
    exposeDeclarationFound = true;
  }

	@Override
	public void caseTPacked(TPacked node) {
		packedDeclarationFound = true;
	}
	
	
	@Override
	public void caseTParallel(TParallel node) {
		parallelizeDeclarationFound = true;
	}
	
	
	@Override
	public void outAMemberDeclaration(AMemberDeclaration node) {
		String type = node.getTypeSpecifier().toString();
		// cut off one space
		type = type.substring(0, type.length() - 1);
		
		Member packedMember = createMemberForPackedClass(type);
		Member unpackedMember = createMemberForUnpackedClass(type);
		orderOfElements.add(memberName);
		
		if (persistentDeclarationFound) {
			Struct packedStruct = packedClass.getStruct();
			Struct unpackedStruct = unpackedClass.getStruct();
			
			packedStruct.addMember(packedMember);
			unpackedStruct.addMember(unpackedMember);
		} else {
			packedClass.addMember(packedMember);
			unpackedClass.addMember(unpackedMember);
		}
	}

	
	private Type createTypeObject(String type, String classname) {
		Type typeObject;

		if (Type.isEnum(type)) {
			typeObject = unpackedClass.getEnumeration(type);
		} else {
			typeObject = new Type(type, "");
		}
		
		if (arraySize != null) {
			typeObject = NameTranslatorFactory.getNameTranslator().getArrayDataType(typeObject, arraySize.getStringRepresentation());
		}
		
		return typeObject;
	}
	
	
	private Member createMemberForPackedClass(String type) {
		Member member;
		String classname;
		if ("".equals(packedClass.getNamespace())) {
			classname = packedClass.getClassname();
		} else {
			classname = packedClass.getNamespace()+"::"+packedClass.getClassname();
	    }
		Type typeObject = createTypeObject(type, classname);
		
		if (packedDeclarationFound) {
			member = new PackedMember(memberName, type);
			
			// packed enumerations
			if (unpackedClass.getEnumeration(type) != null) {
				start = 0;
				end = unpackedClass.getEnumeration(type).numberOfValues() - 1;
			}
			
			((PackedMember) member).setRangeStart(start);
			((PackedMember) member).setRangeEnd(end);
			((PackedMember) member).setBitFieldType(packedFieldType.getTypeString(false));
			
		} else {
			member = new Member(memberName, type);
		}
		
		member.setMappedVariable(NameTranslatorFactory.getNameTranslator().getAttributeName(memberName));
		member.setClassName(classname);
		member.setPersistent(persistentDeclarationFound);
		member.setParallel(parallelizeDeclarationFound);
		member.setExposed(exposeDeclarationFound);
		member.setArraySize(arraySize);
		Mapper mapper = MapperFactory.getInstance().getMapperForMember(member, typeObject);
		member.setMapper(mapper);
		
		if (packedDeclarationFound) {			
			Size memberSize = RangeCalculator.calculateBits(start, end);
			Type memberType = ((PackedMember) member).getMapper().getTypeObject();
			memberType.setSize(memberSize);
		}
		
		return member;
	}
	
	private Member createMemberForUnpackedClass(String type) {
		// initialize enums with name of packed class (necessary for conversion methods)
		String classname;
		if ("".equals(packedClass.getNamespace())) {
			classname = packedClass.getClassname();
		} else {
			classname = packedClass.getNamespace()+"::"+packedClass.getClassname();
	    }
		Type typeObject = createTypeObject(type, classname);
		
		if ("".equals(unpackedClass.getNamespace())) {
			classname = unpackedClass.getClassname();
		} else {
			classname = unpackedClass.getNamespace()+"::"+unpackedClass.getClassname();
	    }
		Member member = new Member(memberName, type);
		member.setMappedVariable(NameTranslatorFactory.getNameTranslator().getAttributeName(memberName));
		member.setClassName(classname);
		member.setPersistent(persistentDeclarationFound);
		member.setParallel(parallelizeDeclarationFound);
		member.setExposed(exposeDeclarationFound);
		member.setArraySize(arraySize);
		Mapper mapper = MapperFactory.getInstance().getMapperForMember(member, typeObject);
		member.setMapper(mapper);
		
		return member;
	}
	
	@Override
    public void inAIdentifierDeclarator(AIdentifierDeclarator node) {
        memberName = node.getIdentifier().getText();
    }
	
	@Override
	public void inAArrayDeclarator(AArrayDeclarator node) {
		memberName = node.getIdentifier().getText();
	}
	
	@Override
	public void inAParamArrayDimension(AParamArrayDimension node) {
		arraySize = ConstantSizes.get(node.getIdentifier().getText());
		if (arraySize == null) {
			arraySize = new Size(node.getIdentifier().getText());
		}
	}
	
	@Override
	public void inAConstantArrayDimension(AConstantArrayDimension node) {
		arraySize = new Size(node.getDecimalConstant().getText());
	}
   
    
    @Override
    public void inASignedBegin(ASignedBegin node) {
   		start = Integer.parseInt(node.getSignedDecimalConstant().getText());
    }
    
    @Override
    public void inAUnsignedBegin(AUnsignedBegin node) {
   		start = Integer.parseInt(node.getDecimalConstant().getText());
    }
    
    @Override
    public void inASignedEnd(ASignedEnd node) {
   		end = Integer.parseInt(node.getSignedDecimalConstant().getText());
    }
    
    @Override
    public void inAUnsignedEnd(AUnsignedEnd node) {
   		end = Integer.parseInt(node.getDecimalConstant().getText());
    }
    
	
	/** 
	 * intended only for testing purpose!
	 */
	public Class getPackedClass() {
		return packedClass;
	}
	
	/** 
	 * intended only for testing purpose!
	 */
	public Class getUnpackedClass() {
		return unpackedClass;
	}
	
	
}
