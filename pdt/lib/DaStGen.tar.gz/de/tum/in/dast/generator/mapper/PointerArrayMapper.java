// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.mapper;

import de.tum.in.dast.generator.DaStConfiguration;
import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.naming.NameTranslator;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.util.DaStStringBuilder;

/**
 * Implementation of interface Mapper, for members which represent arrays.
 * The c++-datatype specified via the constructor should have the operator
 * [] (access the i-th element ofthe array), as this is used in the 
 * generated toString-method.
 * 
 * @author Wolfgang Eckhardt, Tobias Weinzierl
 *
 */
public class PointerArrayMapper implements Mapper {

	protected Member member;
	protected Type type;
	protected NameTranslator translator = NameTranslatorFactory.getNameTranslator();
	
	/**
	 * Construct a new ArrayMapper. 
	 * A "mapped type" is created of the prefix + member.getType + 
	 * 
	 * @param member the member, which is mapped
	 * @param prefix the prefix for the mapped type
	 * @param postfix the postfix for the mapped type
	 */
	public PointerArrayMapper(Member member, Type type) {
		this.type = type;
		this.member = member;
	}
	
	public int getNumberOfOperations() {
	  return 4;
	}
	
	public void writeMethodSignature(int operationNumber, DaStStringBuilder builder) {
	  switch (operationNumber) {
	    case 0:
			writeMethodComment(builder);
	    	builder.append( getGetMethodSignature(false) );
	    	builder.append( ";" );
	    	break;
	    case 1:
  			writeMethodComment(builder);
	    	builder.append( getSetMethodSignature(false) );
	    	builder.append( ";" );
	    	break;
	    case 2:
  			writeMethodComment(builder);
      	builder.append( getGetElementMethodSignature(false) );
	    	builder.append( ";" );
	    	break;
	    case 3:
	  		writeMethodComment(builder);
	    	builder.append( getSetElementMethodSignature(false) );
	    	builder.append( ";" );
	    	break;
	    default: throw new RuntimeException( "Only operation 0 to 3 supported" );
	  }
	}
		
	public void writeMethodImplementation(int operationNumber, DaStStringBuilder builder) {
	  switch (operationNumber) {
	    case 0:
	    	getGetMethod(builder);
	    	break;
	    case 1:
	    	getSetMethod(builder);
	    	break;
	    case 2:
	    	getGetElementMethod(builder);
	    	break;
	    case 3:
	    	getSetElementMethod(builder);
	    	break;
	    default: throw new RuntimeException( "Only operation 0 and 1 supported" );
	  }
	}
	
	// this creates a "real" getter, which returns a reference to our intern object.
	private void getGetMethod(DaStStringBuilder builder) {
		builder.indent();
    writeMethodComment(builder);
		builder.append(getGetMethodSignature(!DaStConfiguration.manuallyInline) + " {");
		builder.incrementAndIndent(getClass().getName());
		getGetMethodBody(builder);
		builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("}");
	}

	private String getGetElementMethodSignature(boolean qualified) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
    if (qualified) {
      qualifiedClassName = member.getClassName() + "::";
    }
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
    return 
      prefix + 
      " " + 
      type.getInnerType().getTypeString(true) + 
      " " + 
      qualifiedClassName 
      + translator.getGetter(member.getMemberName())+"(int elementIndex) const" 
      + " "
      + attributes;
	}
	
	private String getSetElementMethodSignature(boolean qualified) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
	  if (qualified) {
        qualifiedClassName = member.getClassName() + "::";
      }
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
    return   prefix 
             + " void " 
             + qualifiedClassName 
             + translator.getSetter(member.getMemberName()) 
             + "(int elementIndex, const " + member.getType() + "& " 
             + translator.getArgumentName(member.getMemberName())+")"
             + " "
             + attributes;
	}

  private String getSetMethodSignature(boolean qualified) {
	  String prefix             = "";
	  String qualifiedClassName = "";
	  String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
	  if (qualified) {
	    qualifiedClassName = member.getClassName() + "::";
	  }
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
	  return prefix + 
	         " void " + qualifiedClassName + 
	    translator.getSetter(member.getMemberName()) + 
	    "(const "+ type.getTypeString(false)+"& "+translator.getArgumentName(member.getMemberName())+")"
	    + " "
	    + attributes;
	}
	  
	private String getGetMethodSignature(boolean qualified) {
	    String prefix             = "";
      String qualifiedClassName = "";
      String attributes         = "";
      if (DaStConfiguration.manuallyInline) {
        prefix += "inline";
      }
      if (qualified) {
        qualifiedClassName = member.getClassName() + "::";
      }
      if (DaStConfiguration.manuallyInline) {
        attributes += AttributeInline;
      }
      return prefix 
             + " "  
             + type.getTypeString(qualified)
             + " " 
             + qualifiedClassName 
             + translator.getGetter(member.getMemberName())+"() const"
             + " " 
             + attributes
             ;
	}
	
	protected void getGetMethodBody(DaStStringBuilder builder) {
        	builder.append("return "+member.getMappedVariable()+";");
	}


	private void getSetMethod(DaStStringBuilder builder) {
		builder.indent();
    writeMethodComment(builder);
		builder.append(getSetMethodSignature(!DaStConfiguration.manuallyInline) + " {");
		builder.incrementAndIndent(getClass().getName());
		getSetMethodBody(builder);
		builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("}");
	}

	private void getGetElementMethod(DaStStringBuilder builder) {
		builder.indent();
		builder.append(getGetElementMethodSignature(!DaStConfiguration.manuallyInline) + " {");
		builder.incrementAndIndent(getClass().getName());
        getGetElementMethodBody(builder);
		builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("}");
	}

	private void getSetElementMethod(DaStStringBuilder builder) {
		builder.indent();
		builder.append(getSetElementMethodSignature(!DaStConfiguration.manuallyInline) + " {");
		builder.incrementAndIndent(getClass().getName());
        getSetElementMethodBody(builder);
		builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("}");
	}

	protected void getSetMethodBody(DaStStringBuilder builder) {
       	builder.append(member.getMappedVariable() + " = (" + translator.getArgumentName(member.getMemberName()) + ");");
	}
	
	void writeElementAccessAssertions(DaStStringBuilder builder) {
      builder.append( translator.getAssertion() );
      builder.append( "(elementIndex>=0" );
      builder.appendAndIndent( ");" );
      builder.append( translator.getAssertion() );
      builder.append( "(elementIndex<" );
      builder.append( member.getArraySize().getStringRepresentation() );
      builder.appendAndIndent( ");" );
	}

	protected void getSetElementMethodBody(DaStStringBuilder builder) {
      String attributeName = member.getMappedVariable();
	  writeElementAccessAssertions(builder);
      builder.appendAndIndent( attributeName + "[elementIndex]" + "= "+ translator.getArgumentName(member.getMemberName())+";" );
	}

	protected void getGetElementMethodBody(DaStStringBuilder builder) {
      String attributeName = member.getMappedVariable();
	  writeElementAccessAssertions(builder);
      builder.appendAndIndent( "return " + attributeName + "[elementIndex];" );
	}

	public String getMappedDataType() {
		return type.getTypeString(false);
	}
	
//	@Override java 1.5 doesn't accept override annotation for interfaces
	public void writeDeclaration(DaStStringBuilder builder, boolean currentClassIsPacked) {	  
	  String declarationWithoutSemicolon =       
	    getMappedDataType() + " " + 
	    translator.getAttributeName(member.getMemberName() );


	  if (DaStConfiguration.manuallyAlign && !currentClassIsPacked) {
      builder.appendAndIndent( "#ifdef " + translator.getCFVectorAlignment() );
      builder.append( declarationWithoutSemicolon );
	    builder.appendAndIndent( " __attribute__((aligned(VectorisationAlignment)));"  );
      builder.appendAndIndent( "#else" );
      builder.appendAndIndent( declarationWithoutSemicolon + ";");
      builder.appendAndIndent( "#endif" );
	  }
	  else {
	    builder.appendAndIndent( declarationWithoutSemicolon + ";");
	  }
	}


	public String getToString() {
		DaStStringBuilder builder = new DaStStringBuilder(); 
		builder.incrementIndentLevel(getClass().getName());
		
		builder.appendAndIndent("out << \"" + member.getMemberName() + ":[\";");
		builder.append("for (int i = 0; i < "+ member.getArraySize().getStringRepresentation() +"-1; i++) {");
		builder.incrementAndIndent(getClass().getName());
		builder.append("out << " + translator.getGetter(member.getMemberName()) + "(i) << \",\";");
		builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("}");
		builder.append("out << " + translator.getGetter(member.getMemberName()) + "(" + 
				member.getArraySize().getStringRepresentation() + "-1) << \"]\";");
		
		return builder.toString();
	}

	/**
	 * @return "0". This mapper doesn't support the 
	 * 			compression of members, so they don't 
	 * 			need space in a bitfield
	 */
	public Size getBitfieldLength() {
		return new Size(0);
	}

	public Type getTypeObject() {
		return type;
	}


//	@Override java 1.5 doesn't accept override annotation for interfaces
	public void writeConstructorAssertions(DaStStringBuilder builder) {
		// No assertions to insert - do nothing.
	}

	protected void writeMethodComment(DaStStringBuilder builder) {
	  if (DaStConfiguration.manuallyAlign) {
	    builder.appendAndIndent("/**");
      builder.appendAndIndent(" * Generated and optimized");
      builder.appendAndIndent(" * ");
      builder.appendAndIndent(" * If you realise a for loop using exclusively arrays (vectors) and compile ");
      builder.appendAndIndent(" * with -D" + translator.getCFVectorAlignment() + " you may add ");
      builder.appendAndIndent(" * \\code" );
      builder.appendAndIndent(" #pragma vector aligned");
      builder.appendAndIndent(" #pragma simd" );
      builder.appendAndIndent(" \\endcode to this for loop to enforce your compiler to use SSE/AVX.");
      builder.appendAndIndent(" * ");
      builder.appendAndIndent(" * The alignment is tied to the unpacked records, i.e. for packed class");
      builder.appendAndIndent(" * variants the machine's natural alignment is switched off to recude the  ");
      builder.appendAndIndent(" * memory footprint. Do not use any SSE/AVX operations or " );
      builder.appendAndIndent(" * vectorisation on the result for the packed variants, as the data is misaligned. " );
      builder.appendAndIndent(" * If you rely on vectorisation, convert the underlying record " );
      builder.appendAndIndent(" * into the unpacked version first. " );
      builder.appendAndIndent(" * " );
      builder.appendAndIndent(" * @see convert()" );
	    builder.appendAndIndent(" */");
	  }
	}


	
	@Override
  public boolean passObjectsInConstructorViaConstReference() {
  	return false;
  }
}
