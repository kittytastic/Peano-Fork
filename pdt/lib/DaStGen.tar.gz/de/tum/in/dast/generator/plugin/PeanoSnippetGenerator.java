// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.plugin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import de.tum.in.dast.generator.DaStConfiguration;
import de.tum.in.dast.generator.DastGenAST.DaStGenASTBuilder;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.mapper.MapperFactory;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.memberSelection.PackedMember;
import de.tum.in.dast.generator.naming.NameTranslator;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.util.DaStStringBuilder;

public class PeanoSnippetGenerator implements CodePlugin {
	
	public void generateDefinition(DaStConfiguration configuration, 
			DaStStringBuilder stringBuilder, String qualifiedClassName, List<Member> virtualMembers, List<Member> internalMembers) {
		
		System.out.println( "*** use PeanoSnippetGenerator" );
		
		stringBuilder.indent();
		stringBuilder.append("#ifdef Parallel");
		stringBuilder.incrementAndIndent(getClass().getName()+"::generateDefinition()");
		
		// write code for attributes
		
		stringBuilder.append("protected:");
		stringBuilder.incrementAndIndent(getClass().getName()+"::generateDefinition()" );
		stringBuilder.appendAndIndent("static tarch::logging::Log _log;");  
		stringBuilder.indent();
		stringBuilder.appendAndIndent("int _senderDestinationRank;");
		stringBuilder.decrementAndIndent(getClass().getName()+"::generateDefinition()");

		// write code for methods
		stringBuilder.append("public:");
		stringBuilder.incrementAndIndent(getClass().getName()+"::generateDefinition()");
		stringBuilder.indent();
		stringBuilder.appendAndIndent("/**");
		stringBuilder.appendAndIndent(" * Global that represents the mpi datatype.");
		stringBuilder.appendAndIndent(" * There are two variants: Datatype identifies only those attributes marked with");
		stringBuilder.appendAndIndent(" * parallelise. FullDatatype instead identifies the whole record with all fields.");
		stringBuilder.appendAndIndent(" */");
		stringBuilder.appendAndIndent("static MPI_Datatype Datatype;");
		stringBuilder.append("static MPI_Datatype FullDatatype;");
		stringBuilder.indent(2);
		
		stringBuilder.appendAndIndent("/**");
		stringBuilder.appendAndIndent(" * Initializes the data type for the mpi operations. Has to be called");
		stringBuilder.appendAndIndent(" * before the very first send or receive operation is called.");
		stringBuilder.appendAndIndent(" */");
		stringBuilder.appendAndIndent("static void initDatatype();");
		stringBuilder.indent();
        stringBuilder.appendAndIndent("static void shutdownDatatype();");
        stringBuilder.indent();
		stringBuilder.appendAndIndent("enum class ExchangeMode { Blocking, NonblockingWithPollingLoopOverTests, LoopOverProbeWithBlockingReceive };");
        stringBuilder.indent();
		stringBuilder.appendAndIndent("void send(int destination, int tag, bool exchangeOnlyAttributesMarkedWithParallelise, ExchangeMode mode );");
		stringBuilder.indent();
		stringBuilder.appendAndIndent("void receive(int source, int tag, bool exchangeOnlyAttributesMarkedWithParallelise, ExchangeMode mode );");
		stringBuilder.indent();
		stringBuilder.appendAndIndent("static bool isMessageInQueue(int tag, bool exchangeOnlyAttributesMarkedWithParallelise);");
		stringBuilder.indent();
		stringBuilder.appendAndIndent("int getSenderRank() const;");
		stringBuilder.decrementIndentLevel(getClass().getName()+"::generateDefinition()"); // one after the visibility markers
		stringBuilder.decrementIndentLevel(getClass().getName()+"::generateDefinition()"); // one after the ifdefs 
		stringBuilder.append("#endif");
	}
	

	
	
	public void generateImplementation(DaStConfiguration configuration, 
		DaStStringBuilder stringBuilder, String qualifiedClassName, List<Member> virtualMembers, List<Member> internalMembers) {
		
		stringBuilder.append("#ifdef Parallel");
		stringBuilder.incrementAndIndent(getClass().getName() + "::generateImplementation()" );
		
		stringBuilder.appendAndIndent("tarch::logging::Log "+qualifiedClassName+"::_log( \""+qualifiedClassName+"\" );");
		stringBuilder.indent();
		stringBuilder.appendAndIndent("MPI_Datatype "+qualifiedClassName+"::Datatype = 0;");
		stringBuilder.appendAndIndent("MPI_Datatype "+qualifiedClassName+"::FullDatatype = 0;");
		stringBuilder.indent();
		
		generateMPIInit(internalMembers, stringBuilder, qualifiedClassName);
		generateMPIShutdown(stringBuilder, qualifiedClassName);
		generateSendMethod(stringBuilder, qualifiedClassName);
		generateReceiveMethod(stringBuilder, qualifiedClassName);
		generateIsMessageInQueueMethod(stringBuilder, qualifiedClassName);
		generateGetSenderRank(stringBuilder, qualifiedClassName);

		stringBuilder.decrementAndIndent(getClass().getName() + "::generateImplementation()" );
		stringBuilder.appendAndIndent("#endif");
		stringBuilder.indent(2);
	}
	
	private void generateMPIShutdown(DaStStringBuilder builder, String className) {
		builder.indent();
        builder.append("void "+className+"::shutdownDatatype() {");
        builder.incrementAndIndent(getClass().getName()+"::generateMPIShutdown()");

        String simpleClassName = className.substring(className.lastIndexOf(":")+1);

        builder.appendAndIndent("MPI_Type_free( &"+simpleClassName+"::Datatype );");
        builder.appendAndIndent("MPI_Type_free( &"+simpleClassName+"::FullDatatype );");
        builder.decrementAndIndent(getClass().getName()+"::generateMPIShutdown()");
        builder.appendAndIndent("}");
        builder.indent();
	}


	private void generateMPIInit(List<Member> members, DaStStringBuilder builder, String className) {
		//if (!DaStConfiguration.generateParallelCode || CodeGenerator.getState() == State.OUTER_UNPACKED) {
		// TODO the "problem" of generating mpi_init for not packed data is rooted in
		// single boolean values and boolean arrays => how to send a std::bitset???
		// the answer could give each Mapper, then the code below would become much simpler anyway.
		// Moreover the generation of parallel code should be determined only by the boolean flag. 
		// => extract the settings to application wide settings, as suggested in main class?
		//	return;
		//}
		
	  NameTranslator translator      = NameTranslatorFactory.getNameTranslator();
      String         simpleClassName = className.substring(className.lastIndexOf(":")+1);

      builder.indent();
      builder.append("void "+className+"::initDatatype() {");
      builder.incrementAndIndent(getClass().getName()+"::generateMPIInit()");

		List<Member> parallelMembers = (List<Member>) new ArrayList<Member>();
		for (Member m: members) {
			if (m.isParallel()) {
				parallelMembers.add(m);
			}
		}
    Collections.sort(parallelMembers);
		
    builder.append("{");
    builder.incrementAndIndent(getClass().getName() + "::initMPIDatatype()");
	initMPIDatatype(
	  builder, className, simpleClassName,
      parallelMembers, translator,
      simpleClassName+"::Datatype"
    );
	builder.decrementAndIndent(getClass().getName() + "::initMPIDatatype()");
	builder.appendAndIndent("}");

		
    List<Member> allMembers = (List<Member>) new ArrayList<Member>();
    for (Member m: members) {
      allMembers.add(m);
    }
    Collections.sort(allMembers);

    builder.append("{");
    builder.incrementAndIndent(getClass().getName() + "::FullDatatype" );
    initMPIDatatype(
      builder, className, simpleClassName,
      allMembers, translator,
      simpleClassName+"::FullDatatype"
    );
    builder.decrementAndIndent(getClass().getName() + "::FullDatatype");
    builder.appendAndIndent("}");
				
		builder.decrementAndIndent(getClass().getName()+"::generateMPIInit()");
		builder.appendAndIndent("}");
		builder.indent();
	}




  private void initMPIDatatype(
    DaStStringBuilder builder, String className, String simpleClassName,
    List<Member> parallelMembers, NameTranslator translator,
    String mpiDatatypeName
  ) {
        int numParallelMembers = 0;
        for (Member m: parallelMembers) {
          numParallelMembers += (Type.COMPLEX.equals(m.getType()) && m.getArraySize()==null) ? 2 : 1;
        }
		
	    builder.appendAndIndent(simpleClassName+" dummy"+simpleClassName+"[2];");
	    builder.indent();

		/**
		 * Create MPI datastructure for attributes marked with parallelise 
		 * 
		 */
      	builder.appendAndIndent("#ifdef MPI2");
      	builder.appendAndIndent("const int Attributes = "+(numParallelMembers)+";");
      	builder.appendAndIndent("#else");
      	builder.appendAndIndent("const int Attributes = "+(numParallelMembers+1)+";");
      	builder.appendAndIndent("#endif");
		builder.append("MPI_Datatype subtypes[Attributes] = {");
		builder.incrementAndIndent(getClass().getName()+"::initMPIDatatype()");

		String separator = " ";
		for (Member m: parallelMembers) {
			// Bugfix for packed doubles
			if (Type.DOUBLE.equals(m.getType()) && m.isPacked() && MapperFactory.supportPackedDoubles) {
				builder.appendAndIndent( separator + " " + Type.getMPIType(((PackedMember) m).getPackedType(), false)+"\t\t //"+m.getMemberName());
			} 
			else if (Type.COMPLEX.equals(m.getType()) && m.getArraySize()==null) {
                builder.appendAndIndent(separator + " " + Type.getMPIType(m.getType(), false)+"\t\t //"+m.getMemberName());
                builder.appendAndIndent(", " + Type.getMPIType(m.getType(), false)+"\t\t //"+m.getMemberName());
			}
			else {
				boolean isArray = (m.getArraySize() != null);
				builder.appendAndIndent(separator + " " + Type.getMPIType(m.getType(), isArray)+"\t\t //"+m.getMemberName());
			}
			separator= ",";
		}

		builder.appendAndIndent("#ifndef MPI2");
      	builder.appendAndIndent(", MPI_UB");
      	builder.appendAndIndent("#endif");
		
		builder.decrementAndIndent(getClass().getName()+"::initMPIDatatype()");
		builder.appendAndIndent("};");
		builder.indent();
		
		builder.append("int blocklen[Attributes] = {");
		builder.incrementAndIndent(getClass().getName() + "::initMPIDatatype()/cardinalities" );
		separator = " ";
		for (Member m: parallelMembers) {
          if (Type.COMPLEX.equals(m.getType())&& m.getArraySize()==null) {
            builder.appendAndIndent(separator + " 1\t\t //"+m.getMemberName());       
            builder.appendAndIndent(", 1\t\t //"+m.getMemberName());       
          }
          else if (Type.COMPLEX.equals(m.getType())&& m.getArraySize()!=null) {
            builder.appendAndIndent(separator + " " + m.getArraySize().getStringRepresentation()+"*2\t\t //"+m.getMemberName());       
          }
          else if (m.getArraySize() != null) {
     	      builder.appendAndIndent(separator + " " + m.getArraySize().getStringRepresentation()+"\t\t //"+m.getMemberName());		    
	   	  }
          else {
            builder.appendAndIndent(separator + " 1\t\t //"+m.getMemberName());       
          }
          separator= ",";
		}

		builder.appendAndIndent("#ifndef MPI2");
      	builder.appendAndIndent(", 1");
      	builder.appendAndIndent("#endif");
		
      	builder.decrementAndIndent(getClass().getName()  + "::initMPIDatatype()/cardinalities" );
		builder.appendAndIndent("};");
		builder.indent();

		builder.appendAndIndent("MPI_Aint  disp[Attributes];");
		builder.appendAndIndent("MPI_Aint  base;");

		
		builder.appendAndIndent("#ifdef MPI2");
		builder.appendAndIndent("MPI_Get_address( const_cast<void*>(static_cast<const void*>(&(dummy"+ simpleClassName +"))), &base);");		
		builder.appendAndIndent("#else");
		builder.appendAndIndent("MPI_Address( const_cast<void*>(static_cast<const void*>(&(dummy"+ simpleClassName +"))), &base);");		
		builder.appendAndIndent("#endif");
		int elementNumber = 0;
        for (Member m: parallelMembers) {
    		String memberName = "";
			if (m.isPersistent()) {
				memberName = "dummy"+simpleClassName + "[0]." 
					+ translator.getAttributeName(DaStGenASTBuilder.FIELD_PERSISTENT_RECORDS) 
					+ "." + translator.getAttributeName(m.getMemberName());
			} else {
				memberName = "dummy"+simpleClassName + "[0]." 
				+ translator.getAttributeName(m.getMemberName());
			}
			if (m.getArraySize() != null && !Type.BOOL.equals(m.getType())) {
              builder.appendAndIndent("#ifdef MPI2");
     	      builder.appendAndIndent("MPI_Get_address( const_cast<void*>(static_cast<const void*>(&(" + memberName+"[0]))), \t\t&disp["+elementNumber+"] );");
              builder.appendAndIndent("#else");
     	      builder.appendAndIndent("MPI_Address( const_cast<void*>(static_cast<const void*>(&(" + memberName+"[0]))), \t\t&disp["+elementNumber+"] );");
              builder.appendAndIndent("#endif");
			} 
            else if (Type.COMPLEX.equals(m.getType())) {
              builder.appendAndIndent("#ifdef MPI2");
              builder.appendAndIndent("MPI_Get_address( const_cast<void*>(static_cast<const void*>(&(reinterpret_cast<double*>(" + memberName+")[0] ))), \t\t&disp["+elementNumber+"] );");
              builder.appendAndIndent("#else");
              builder.appendAndIndent("MPI_Address( const_cast<void*>(static_cast<const void*>(&(reinterpret_cast<double*>(" + memberName+")[0] ))), \t\t&disp["+elementNumber+"] );");
              builder.appendAndIndent("#endif");
              elementNumber++;
              builder.appendAndIndent("#ifdef MPI2");
              builder.appendAndIndent("MPI_Get_address( const_cast<void*>(static_cast<const void*>(&(reinterpret_cast<double*>(" + memberName+")[1] ))), \t\t&disp["+elementNumber+"] );");
              builder.appendAndIndent("#else");
              builder.appendAndIndent("MPI_Address( const_cast<void*>(static_cast<const void*>(&(reinterpret_cast<double*>(" + memberName+")[1] ))), \t\t&disp["+elementNumber+"] );");
              builder.appendAndIndent("#endif");
             }
			else {
              builder.appendAndIndent("#ifdef MPI2");
     	      builder.appendAndIndent("MPI_Get_address( const_cast<void*>(static_cast<const void*>(&(" + memberName+"))), \t\t&disp["+elementNumber+"] );");
              builder.appendAndIndent("#else");
     	      builder.appendAndIndent("MPI_Address( const_cast<void*>(static_cast<const void*>(&(" + memberName+"))), \t\t&disp["+elementNumber+"] );");
              builder.appendAndIndent("#endif");
			}
			elementNumber++;
		}

        builder.appendAndIndent("#ifdef MPI2");
		builder.appendAndIndent("for (int i=1; i<Attributes; i++) {");
        builder.appendAndIndent("#else");
		builder.appendAndIndent("for (int i=1; i<Attributes-1; i++) {");
        builder.append("#endif");
		builder.incrementAndIndent(getClass().getName());
		builder.append("assertion1( disp[i] > disp[i-1], i );");
		builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("}");
		
        builder.appendAndIndent("#ifdef MPI2");
		builder.appendAndIndent("for (int i=0; i<Attributes; i++) {");
        builder.appendAndIndent("#else");
		builder.appendAndIndent("for (int i=0; i<Attributes-1; i++) {");
        builder.append("#endif");
		builder.incrementAndIndent(getClass().getName());
		builder.appendAndIndent("disp[i] = disp[i] - base; // should be MPI_Aint_diff(disp[i], base); but this is not supported by most MPI-2 implementations");
		builder.append("assertion4(disp[i]<static_cast<int>(sizeof(" + simpleClassName + ")), i, disp[i], Attributes, sizeof("  + simpleClassName + "));");
		builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("}");
		
        builder.appendAndIndent("#ifndef MPI2");
		builder.appendAndIndent("MPI_Address( const_cast<void*>(static_cast<const void*>(&(dummy"+ simpleClassName +"[1]))), \t\t&disp["+elementNumber+"] );");
		builder.appendAndIndent("disp["+elementNumber+"] -= base;");
		builder.appendAndIndent("disp["+elementNumber+"] += disp[0];");
		builder.appendAndIndent("#endif");

        builder.appendAndIndent("#ifdef MPI2");
		builder.appendAndIndent("MPI_Datatype tmpType; ");
		builder.appendAndIndent("MPI_Aint lowerBound, typeExtent; ");
		builder.appendAndIndent("MPI_Type_create_struct( Attributes, blocklen, disp, subtypes, &tmpType );" );
		builder.appendAndIndent("MPI_Type_get_extent( tmpType, &lowerBound, &typeExtent );" );
		builder.appendAndIndent("MPI_Type_create_resized( tmpType, lowerBound, typeExtent, &"+mpiDatatypeName+" );");
		builder.appendAndIndent("MPI_Type_commit( &"+mpiDatatypeName+" );");  
        builder.appendAndIndent("#else");
		builder.appendAndIndent("MPI_Type_struct( Attributes, blocklen, disp, subtypes, &" + mpiDatatypeName + ");" );
		builder.appendAndIndent("MPI_Type_commit( &"+mpiDatatypeName+" );");  
        builder.appendAndIndent("#endif");
   }

  
	public void generateSendMethod(DaStStringBuilder stringBuilder, String className) {
		//Send Operation
		stringBuilder.append("void "+className+"::send(int destination, int tag, bool exchangeOnlyAttributesMarkedWithParallelise, ExchangeMode mode) {");
		stringBuilder.incrementAndIndent(getClass().getName()+"::generateSendMethod()");
		stringBuilder.appendAndIndent( getSendMethodSnippet(className) );
		stringBuilder.decrementAndIndent(getClass().getName()+"::generateSendMethod()");
		stringBuilder.appendAndIndent("}");
		
		stringBuilder.indent(3);
	}	
		
    public static String getSendMethodSnippet(String className) {
      return 
                  "// ============================= \n"
	            + "// start injected snippet/aspect \n"
	            + "// ============================= \n"
	      		+ "switch (mode) { \n"
	    		+ "  case ExchangeMode::Blocking: \n"
	    		+ "    {\n"
	    		+ "      const int result = MPI_Send(this, 1, exchangeOnlyAttributesMarkedWithParallelise ? Datatype : FullDatatype, destination, tag, tarch::parallel::Node::getInstance().getCommunicator()); \n "
	    		+ "      if  (result!=MPI_SUCCESS) { \n "
	    		+ "        std::ostringstream msg; \n "
	    		+ "        msg << \"was not able to send message " + className + " \" \n "
	    		+ "            << toString() \n "
	    		+ "            << \" to node \" << destination \n "
	    		+ "            << \": \" << tarch::parallel::MPIReturnValueToString(result); \n "
	    		+ "        _log.error( \"send(int)\",msg.str() ); \n "
	    		+ "      } \n"
	    		+ "    } \n"
	    		+ "    break; \n "
	    		+ "  case ExchangeMode::NonblockingWithPollingLoopOverTests: \n"
	    		+ "    {\n"
	    		+ "      MPI_Request* sendRequestHandle = new MPI_Request(); \n"
	    		+ "      int          flag = 0; \n "
	            + "      int          result; \n "
	            + "      clock_t      timeOutWarning   = -1; \n "
	            + "      clock_t      timeOutShutdown  = -1; \n "
	            + "      bool         triggeredTimeoutWarning = false;  \n "
	            + "      result = MPI_Isend(  \n "
	            + "        this, 1, exchangeOnlyAttributesMarkedWithParallelise ? Datatype : FullDatatype, destination,  \n "
	            + "        tag, tarch::parallel::Node::getInstance().getCommunicator(), \n "
	            + "        sendRequestHandle  \n "
	            + "      ); \n "
	            + "      if  (result!=MPI_SUCCESS) {  \n "
	            + "        std::ostringstream msg;  \n "
	            + "        msg << \"was not able to send message " + className + " \"  \n "
	            + "            << toString() \n "
	            + "            << \" to node \" << destination \n "
	            + "            << \": \" << tarch::parallel::MPIReturnValueToString(result);  \n "
	            + "        _log.error( \"send(int)\",msg.str() );  \n "
	            + "      }  \n "
	            + "      result = MPI_Test( sendRequestHandle, &flag, MPI_STATUS_IGNORE ); \n "
	            + "      while (!flag) { \n "
	            + "        if (timeOutWarning==-1)   timeOutWarning   = tarch::parallel::Node::getInstance().getDeadlockWarningTimeStamp(); \n "
	            + "        if (timeOutShutdown==-1)  timeOutShutdown  = tarch::parallel::Node::getInstance().getDeadlockTimeOutTimeStamp(); \n "
	            + "        result = MPI_Test( sendRequestHandle, &flag, MPI_STATUS_IGNORE ); \n "
	            + "        if (result!=MPI_SUCCESS) { \n "
	            + "          std::ostringstream msg; \n "
	            + "          msg << \"testing for finished send task for " + className + " \" \n "
	            + "              << toString() \n "
	            + "              << \" sent to node \" << destination \n "
	            + "              << \" failed: \" << tarch::parallel::MPIReturnValueToString(result); \n "
	            + "          _log.error(\"send(int)\", msg.str() ); \n "
	            + "        } \n "
	            + "        if ( \n "
	            + "          tarch::parallel::Node::getInstance().isTimeOutWarningEnabled() && \n "
	            + "          (clock()>timeOutWarning) && \n "
	            + "          (!triggeredTimeoutWarning) \n "
	            + "        ) { \n "
	            + "          tarch::parallel::Node::getInstance().writeTimeOutWarning( \n "
	            + "            \"" + className + "\", \n "
	            + "            \"send(int)\", destination,tag,1 \n "
	            + "          ); \n "
	            + "          triggeredTimeoutWarning = true; \n "
	            + "        } \n "
	            + "        if ( \n "
	            + "          tarch::parallel::Node::getInstance().isTimeOutDeadlockEnabled() && \n "
	            + "          (clock()>timeOutShutdown) \n "
	            + "        ) { \n "
	            + "          tarch::parallel::Node::getInstance().triggerDeadlockTimeOut( \n "
	            + "            \"" + className + "\", \n "
	            + "            \"send(int)\", destination,tag,1 \n "
	            + "          ); \n "
	            + "        } \n "
        	    + "	       tarch::parallel::Node::getInstance().receiveDanglingMessages(); \n "
	            + "      } \n "
	            + "      delete sendRequestHandle; \n "
	    		+ "    }  \n "
	    		+ "    break; \n "
	    		+ "  case ExchangeMode::LoopOverProbeWithBlockingReceive: \n"
	    		+ "    assertionMsg(false,\"should not be called\"); \n"
	    		+ "    break; \n"
	    		+ "} \n "
	            + "// ============================= \n"
	            + "// end injected snippet/aspect \n"
	            + "// ============================= \n";
	}

    
	private void generateReceiveMethod(DaStStringBuilder stringBuilder, String className) {
      stringBuilder.append("void "+className+"::receive(int source, int tag, bool exchangeOnlyAttributesMarkedWithParallelise, ExchangeMode mode) {");
	  stringBuilder.incrementAndIndent(getClass().getName() + "::generateReceiveMethod()");
      stringBuilder.appendAndIndent( getReceiveMethodSnippet(className) );
	  stringBuilder.decrementAndIndent(getClass().getName() + "::generateReceiveMethod()");
	  stringBuilder.appendAndIndent( "  _senderDestinationRank = source==MPI_ANY_SOURCE ? status.MPI_SOURCE : source;" );
      stringBuilder.appendAndIndent("}");

      stringBuilder.indent(3);
	}
			
	
	/**
	 * This operations does not send a local field _senderDestinationRank
	 * though most Peano records have such a field.
	 */
    public static String getReceiveMethodSnippet(String className) {
      return ""
+ "// ============================= \n"
+ "// start injected snippet/aspect \n"
+ "// ============================= \n"
+ "MPI_Status status; \n"
+ "switch (mode) { \n"
+ "  case ExchangeMode::Blocking: \n"
+ "    { \n" 
+ "      const int   result = MPI_Recv(this, 1, exchangeOnlyAttributesMarkedWithParallelise ? Datatype : FullDatatype, source, tag, tarch::parallel::Node::getInstance().getCommunicator(), source==MPI_ANY_SOURCE ? &status : MPI_STATUS_IGNORE ); \n" 
+ "      if ( result != MPI_SUCCESS ) { \n"
+ "        std::ostringstream msg; \n"
+ "        msg << \"failed to start to receive "+className+" from node \" \n"
+ "            << source << \": \" << tarch::parallel::MPIReturnValueToString(result); \n"
+ "        _log.error( \"receive(int)\", msg.str() ); \n"
+ "      } \n"
+ "    } \n" 
+ "    break; \n"
+ "  case ExchangeMode::NonblockingWithPollingLoopOverTests: \n"
+ "    { \n"
+ "      int          flag = 0; \n"
+ "      int          result; \n"
+ "      clock_t      timeOutWarning   = -1; \n"
+ "      clock_t      timeOutShutdown  = -1; \n"
+ "      bool         triggeredTimeoutWarning = false; \n"
+ "      MPI_Request* sendRequestHandle = new MPI_Request(); \n "
+ "      result = MPI_Irecv( \n" 
+ "        this, 1, exchangeOnlyAttributesMarkedWithParallelise ? Datatype : FullDatatype, source, tag, \n"
+ "        tarch::parallel::Node::getInstance().getCommunicator(), sendRequestHandle \n"
+ "      ); \n"
+ "      if ( result != MPI_SUCCESS ) { \n"
+ "        std::ostringstream msg; \n"
+ "        msg << \"failed to start to receive "+className+" from node \" \n "
+ "            << source << \": \" << tarch::parallel::MPIReturnValueToString(result); \n"
+ "        _log.error( \"receive(int)\", msg.str() ); \n" 
+ "      } \n" 
+ "      result = MPI_Test( sendRequestHandle, &flag, source==MPI_ANY_SOURCE ? &status : MPI_STATUS_IGNORE ); \n"
+ "      while (!flag) { \n"
+ "        if (timeOutWarning==-1)   timeOutWarning   = tarch::parallel::Node::getInstance().getDeadlockWarningTimeStamp(); \n"
+ "        if (timeOutShutdown==-1)  timeOutShutdown  = tarch::parallel::Node::getInstance().getDeadlockTimeOutTimeStamp(); \n"
+ "        if ( \n"
+ "          tarch::parallel::Node::getInstance().isTimeOutWarningEnabled() && \n"
+ "          (clock()>timeOutWarning) && \n"
+ "          (!triggeredTimeoutWarning) \n"
+ "        ) { \n"
+ "          tarch::parallel::Node::getInstance().writeTimeOutWarning( \n" 
+ "            \""+className+"\", \n" 
+ "            \"receive(int)\", source,tag,1 \n"
+ "          ); \n"
+ "          triggeredTimeoutWarning = true; \n"
+ "        } \n"
+ "        if ( \n"
+ "          tarch::parallel::Node::getInstance().isTimeOutDeadlockEnabled() && \n"
+ "          (clock()>timeOutShutdown) \n"
+ "        ) { \n"
+ "          tarch::parallel::Node::getInstance().triggerDeadlockTimeOut( \n"
+ "            \""+className+"\", \n" 
+ "            \"receive(int)\", source,tag,1 \n"
+ "          ); \n" 
+ "        } \n"
+ "        tarch::parallel::Node::getInstance().receiveDanglingMessages(); \n"
+ "        result = MPI_Test( sendRequestHandle, &flag, source==MPI_ANY_SOURCE ? &status : MPI_STATUS_IGNORE ); \n"
+ "        if (result!=MPI_SUCCESS) { \n"
+ "          std::ostringstream msg; \n"
+ "          msg << \"testing for finished receive task for "+className+" failed: \" \n"
+ "              << tarch::parallel::MPIReturnValueToString(result); \n"
+ "          _log.error(\"receive(int)\", msg.str() ); \n"
+ "        } \n"
+ "      } \n"
+ "      delete sendRequestHandle; \n"
+ "    }"
+ "    break; \n"
+ "  case ExchangeMode::LoopOverProbeWithBlockingReceive: \n"
+ "    {\n"
+ "      int flag; \n"
+ "      clock_t      timeOutWarning   = -1; \n"
+ "      clock_t      timeOutShutdown  = -1; \n"
+ "      bool         triggeredTimeoutWarning = false; \n"
+ "      int result = MPI_Iprobe(source, tag, tarch::parallel::Node::getInstance().getCommunicator(), &flag, MPI_STATUS_IGNORE ); \n " 
+ "      if (result!=MPI_SUCCESS) { \n"
+ "        std::ostringstream msg; \n"
+ "        msg << \"testing for finished receive task for "+className+" failed: \" \n"
+ "            << tarch::parallel::MPIReturnValueToString(result); \n"
+ "        _log.error(\"receive(int)\", msg.str() ); \n"
+ "      } \n"
+ "      while (!flag) { \n"
+ "        if (timeOutWarning==-1)   timeOutWarning   = tarch::parallel::Node::getInstance().getDeadlockWarningTimeStamp(); \n"
+ "        if (timeOutShutdown==-1)  timeOutShutdown  = tarch::parallel::Node::getInstance().getDeadlockTimeOutTimeStamp(); \n"
+ "        if ( \n"
+ "          tarch::parallel::Node::getInstance().isTimeOutWarningEnabled() && \n"
+ "          (clock()>timeOutWarning) && \n"
+ "          (!triggeredTimeoutWarning) \n"
+ "        ) { \n"
+ "          tarch::parallel::Node::getInstance().writeTimeOutWarning( \n" 
+ "            \""+className+"\", \n" 
+ "            \"receive(int)\", source,tag,1 \n"
+ "          ); \n"
+ "          triggeredTimeoutWarning = true; \n"
+ "        } \n"
+ "        if ( \n"
+ "          tarch::parallel::Node::getInstance().isTimeOutDeadlockEnabled() && \n"
+ "          (clock()>timeOutShutdown) \n"
+ "        ) { \n"
+ "          tarch::parallel::Node::getInstance().triggerDeadlockTimeOut( \n"
+ "            \""+className+"\", \n" 
+ "            \"receive(int)\", source,tag,1 \n"
+ "          ); \n" 
+ "        } \n"
+ "        tarch::parallel::Node::getInstance().receiveDanglingMessages(); \n"
+ "        result = MPI_Iprobe(source, tag, tarch::parallel::Node::getInstance().getCommunicator(), &flag, MPI_STATUS_IGNORE ); \n " 
+ "        if (result!=MPI_SUCCESS) { \n"
+ "          std::ostringstream msg; \n"
+ "          msg << \"testing for finished receive task for "+className+" failed: \" \n"
+ "              << tarch::parallel::MPIReturnValueToString(result); \n"
+ "          _log.error(\"receive(int)\", msg.str() ); \n"
+ "        } \n"
+ "      } \n"
+ "      result = MPI_Recv(this, 1, exchangeOnlyAttributesMarkedWithParallelise ? Datatype : FullDatatype, source, tag, tarch::parallel::Node::getInstance().getCommunicator(), source==MPI_ANY_SOURCE ? &status : MPI_STATUS_IGNORE ); \n" 
+ "      if ( result != MPI_SUCCESS ) { \n"
+ "        std::ostringstream msg; \n"
+ "        msg << \"failed to start to receive "+className+" from node \" \n"
+ "            << source << \": \" << tarch::parallel::MPIReturnValueToString(result); \n"
+ "        _log.error( \"receive(int)\", msg.str() ); \n"
+ "      } \n"
+ "    }\n"
+ "    break; \n"
+ "  } \n"
+ "// =========================== \n"
+ "// end injected snippet/aspect \n"
+ "// =========================== \n";
    }


    private void generateIsMessageInQueueMethod(DaStStringBuilder stringBuilder, String className) {

		stringBuilder.append("bool "+className+"::isMessageInQueue(int tag, bool exchangeOnlyAttributesMarkedWithParallelise) {");
		stringBuilder.incrementAndIndent(getClass().getName() + "::generateIsMessageInQueueMethod()");
		stringBuilder.appendAndIndent("MPI_Status status;");
		stringBuilder.appendAndIndent("int  flag        = 0;");
		stringBuilder.append("MPI_Iprobe(");
		stringBuilder.incrementAndIndent(getClass().getName());
		stringBuilder.appendAndIndent("MPI_ANY_SOURCE, tag,"); 
		stringBuilder.append("tarch::parallel::Node::getInstance().getCommunicator(), &flag, &status");
		stringBuilder.decrementAndIndent(getClass().getName());
		stringBuilder.appendAndIndent(");");
		
		
		//stringBuilder.append("return flag != 0;");
		stringBuilder.append("if (flag) {");
		stringBuilder.incrementAndIndent(getClass().getName());
		stringBuilder.appendAndIndent("int  messageCounter;");
		stringBuilder.append("if (exchangeOnlyAttributesMarkedWithParallelise) {");
		stringBuilder.incrementAndIndent(getClass().getName());
		stringBuilder.append("MPI_Get_count(&status, Datatype, &messageCounter);");
		stringBuilder.decrementAndIndent(getClass().getName());
		stringBuilder.appendAndIndent("}");
		stringBuilder.append("else {");
		stringBuilder.incrementAndIndent(getClass().getName());
		stringBuilder.append("MPI_Get_count(&status, FullDatatype, &messageCounter);");
		stringBuilder.decrementAndIndent(getClass().getName());
		stringBuilder.appendAndIndent("}");
		
		stringBuilder.append("return messageCounter > 0;");
		stringBuilder.decrementAndIndent(getClass().getName());
		stringBuilder.appendAndIndent("}");
		stringBuilder.appendAndIndent("else return false;"); 
		
		stringBuilder.decrementAndIndent(getClass().getName() + "::generateIsMessageInQueueMethod()");
		stringBuilder.appendAndIndent("}");
		stringBuilder.indent();
	}
		
	
	private void generateGetSenderRank(DaStStringBuilder stringBuilder, String className) {
		stringBuilder.append("int "+className+"::getSenderRank() const {");
		stringBuilder.incrementAndIndent(getClass().getName() + "::generateGetSenderRank()" );
		stringBuilder.appendAndIndent("assertion( _senderDestinationRank!=-1 );");
		stringBuilder.appendAndIndent("return _senderDestinationRank;");
		stringBuilder.decrementAndIndent(getClass().getName() + "::generateGetSenderRank()" );
		stringBuilder.append("}");
	}

}
