// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator;

import java.util.Set;

import de.tum.in.dast.analysis.DepthFirstAdapter;
import de.tum.in.dast.generator.conditionset.Conditional;
import de.tum.in.dast.node.AConditionalIfInnerDeclarations;
import de.tum.in.dast.node.AConditionalIfOuterDeclarations;
import de.tum.in.dast.node.AConditionalIfnInnerDeclarations;
import de.tum.in.dast.node.AConditionalIfnOuterDeclarations;

/**
 * This is a DepthFirstAdapter, which considers #ifdefs and #ifndefs.
 * If there is an #ifdef or #ifndef, the identifier is stored. 
 * ignoreDeclaration() tells, if the declaration embedded in the #ifdef should 
 * be ignored or not.
 * 
 * @author Wolfgang Eckhardt
 *
 */
public class ConditionalDepthFirstAdapter extends DepthFirstAdapter {

	/** 
	 * the conditions.
	 * Any condition not stored in this set will be ignored
	 */
	protected Set<de.tum.in.dast.generator.conditionset.Conditional> selectedConditions = null;
	
	/**
	 * @param selectedConditions the set, which contains the conditionals which should 
	 * 							 not be ignored (thus a kind of "white list"
	 */
	public ConditionalDepthFirstAdapter(Set<Conditional> selectedConditions) {
		this.selectedConditions = selectedConditions;
	}

	
	public void caseAConditionalIfInnerDeclarations(AConditionalIfInnerDeclarations node) {
		Conditional condition = new de.tum.in.dast.generator.conditionset.Conditional(node.getIdentifier().getText(),de.tum.in.dast.generator.conditionset.Conditional.Type.IfDefined);	  
		if (!selectedConditions.contains(condition)) {
			return;
		} else {
			super.caseAConditionalIfInnerDeclarations(node);
		}
	}
	
	public void caseAConditionalIfnInnerDeclarations(AConditionalIfnInnerDeclarations node) {
		Conditional condition = new de.tum.in.dast.generator.conditionset.Conditional(node.getIdentifier().getText(),de.tum.in.dast.generator.conditionset.Conditional.Type.IfNotDefined);	  
		if (!selectedConditions.contains(condition)) {
			return;
		} else {
			super.caseAConditionalIfnInnerDeclarations(node);
		}
	}
	
	public void caseAConditionalIfOuterDeclarations(AConditionalIfOuterDeclarations node) {
		Conditional condition = new de.tum.in.dast.generator.conditionset.Conditional(node.getIdentifier().getText(),de.tum.in.dast.generator.conditionset.Conditional.Type.IfDefined);	  
		if (!selectedConditions.contains(condition)) {
			return;
		} else {
			super.caseAConditionalIfOuterDeclarations(node);
		}
	}
	
	public void caseAConditionalIfnOuterDeclarations(AConditionalIfnOuterDeclarations node) {
		Conditional condition = new de.tum.in.dast.generator.conditionset.Conditional(node.getIdentifier().getText(),de.tum.in.dast.generator.conditionset.Conditional.Type.IfNotDefined);	  
		if (!selectedConditions.contains(condition)) {
			return;
		} else {
			super.caseAConditionalIfnOuterDeclarations(node);
		}
	}   
	
}
