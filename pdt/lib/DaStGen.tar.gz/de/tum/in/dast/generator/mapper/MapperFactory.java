// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.mapper;

import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.memberSelection.PackedMember;

/**
 * Factory class for mappers. This class determines, which members (i.e. members
 * of which datatype) are mapped to which target code. This means, if they are
 * packed or to which type arrays are mapped.
 * 
 * @author Wolfgang Eckhardt
 * 
 */
public class MapperFactory {

  private static MapperFactory instance;

  public static boolean supportPackedDoubles = true;

  private static boolean supportPackedTypes = true;

  private MapperFactory() {
  }

  public static void setSupportPackedTypes(boolean supportPackedTypes) {
    MapperFactory.supportPackedTypes = supportPackedTypes;
  }

  public static boolean getSupportPackedTypes() {
    return MapperFactory.supportPackedTypes;
  }

  /**
   * Construct the right mapper for a type 
   * 
   * @param member
   * @param type
   * @return
   */
  public Mapper getMapperForMember(Member member, Type type) {
    boolean isPacked = supportPackedTypes && member.isPacked();
    boolean isArray = member.getArraySize() != null;

    if (  isArray &&  isPacked && Type.BOOL.equals(member.getType()) ) {
      // map packed bool[] to bitset
      return new PackedBitSetMapper((PackedMember) member, member.getArraySize().getStringRepresentation());
    }
    else if (  isArray && !isPacked && Type.BOOL.equals(member.getType()) ) {
      // map bool[] to bitset
      return new BitsetMapper(member);
    }
    else if (  isArray &&  isPacked && Type.isEnum(member.getType()) ) {
      return new PackedArrayMapper(member, type);
    }
    else if (  isArray && !isPacked && Type.isEnum(member.getType())) {
      return new ArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && supportPackedDoubles && Type.DOUBLE.equals(member.getType())) {
      return new PackedDoubleArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && !supportPackedDoubles && Type.DOUBLE.equals(member.getType())) {
      System.err.println("WARNING: double packed is not supported");
      return new ArrayMapper(member, type);
    }
    else if (isArray &&   !isPacked && Type.DOUBLE.equals(member.getType())) {
      return new ArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && supportPackedDoubles && Type.FLOAT.equals(member.getType())) {
      System.err.println("WARNING: float packed is not supported");
      return new ArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && !supportPackedDoubles && Type.FLOAT.equals(member.getType())) {
      System.err.println("WARNING: float packed is not supported");
      return new ArrayMapper(member, type);
    }
    else if (isArray &&   !isPacked && Type.FLOAT.equals(member.getType())) {
      return new ArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && supportPackedDoubles && Type.COMPLEX.equals(member.getType())) {
      System.err.println("WARNING: complex packed array is not supported");
      return new ArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && !supportPackedDoubles && Type.COMPLEX.equals(member.getType())) {
      System.err.println("WARNING: complex packed is not supported");
      return new ArrayMapper(member, type);
    }
    else if (isArray &&   !isPacked && Type.COMPLEX.equals(member.getType())) {
      return new ComplexArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && Type.SHORT.equals(member.getType()) && (((PackedMember) member).getRangeStart() != ((PackedMember) member).getRangeEnd())) {
      return new PackedArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && Type.SHORT.equals(member.getType()) && (((PackedMember) member).getRangeStart() == ((PackedMember) member).getRangeEnd())) {
      System.err.println("WARNING: packed scope for short exceeds given range");
      return new ArrayMapper(member, type);
    }
    else if (isArray &&   !isPacked && Type.SHORT.equals(member.getType()) ) {
      return new ArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && Type.INT.equals(member.getType()) && (((PackedMember) member).getRangeStart() != ((PackedMember) member).getRangeEnd())) {
      return new PackedArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && Type.INT.equals(member.getType()) && (((PackedMember) member).getRangeStart() == ((PackedMember) member).getRangeEnd())) {
      System.err.println("WARNING: packed scope for in exceeds given range");
      return new ArrayMapper(member, type);
    }
    else if (isArray &&   !isPacked && Type.INT.equals(member.getType()) ) {
      return new ArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && Type.LONG.equals(member.getType()) && (((PackedMember) member).getRangeStart() != ((PackedMember) member).getRangeEnd())) {
      return new PackedArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && Type.LONG.equals(member.getType()) && (((PackedMember) member).getRangeStart() == ((PackedMember) member).getRangeEnd())) {
      System.err.println("WARNING: packed scope for long exceeds given range");
      return new ArrayMapper(member, type);
    }
    else if (isArray &&   !isPacked && Type.LONG.equals(member.getType()) ) {
      return new ArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && Type.LONGLONG.equals(member.getType()) && (((PackedMember) member).getRangeStart() != ((PackedMember) member).getRangeEnd())) {
      return new PackedArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && Type.LONGLONG.equals(member.getType()) && (((PackedMember) member).getRangeStart() == ((PackedMember) member).getRangeEnd())) {
      System.err.println("WARNING: packed scope for long long exceeds given range");
      return new ArrayMapper(member, type);
    }
    else if (isArray &&   !isPacked && Type.LONGLONG.equals(member.getType()) ) {
      return new ArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && Type.POINTER.equals(member.getType()) && (((PackedMember) member).getRangeStart() != ((PackedMember) member).getRangeEnd())) {
      System.err.println("WARNING: packed array pointers are not supported");
      return new PackedArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && Type.POINTER.equals(member.getType()) && (((PackedMember) member).getRangeStart() == ((PackedMember) member).getRangeEnd())) {
      System.err.println("WARNING: packed array pointers are not supported");
      return new PointerArrayMapper(member, type);
    }
    else if (isArray &&   !isPacked && Type.POINTER.equals(member.getType()) ) {
      return new PointerArrayMapper(member, type);
    }
    else if (isArray &&    isPacked && Type.BYTE.equals(member.getType()) && (((PackedMember) member).getRangeStart() != ((PackedMember) member).getRangeEnd())) {
        return new PackedArrayMapper(member, type);
      }
      else if (isArray &&    isPacked && Type.BYTE.equals(member.getType()) && (((PackedMember) member).getRangeStart() == ((PackedMember) member).getRangeEnd())) {
        System.err.println("WARNING: packed scope for byte (signed char) exceeds given range");
        return new ArrayMapper(member, type);
      }
      else if (isArray &&   !isPacked && Type.BYTE.equals(member.getType()) ) {
        return new ArrayMapper(member, type);
      }
         
         
    else if (  !isArray &&  isPacked && Type.BOOL.equals(member.getType()) ) {
      return new PackedBoolMapper(member);
    }
    else if (  !isArray && !isPacked && Type.BOOL.equals(member.getType()) ) {
      return new SimpleMapper(member, type);
    }
    else if (  !isArray &&  isPacked && Type.isEnum(member.getType()) && (((PackedMember) member).getRangeStart() != ((PackedMember) member).getRangeEnd()) ) {
      return new PackedMapper((PackedMember) member, type);
    }
    else if (  !isArray &&  isPacked && Type.isEnum(member.getType()) && (((PackedMember) member).getRangeStart() == ((PackedMember) member).getRangeEnd()) ) {
      System.err.println("WARNING: packed scope for enum exceeds given range");
      return new SimpleMapper(member, type);
    }
    else if (  !isArray && !isPacked && Type.isEnum(member.getType())) {
      return new SimpleMapper(member, type);
    }
    else if (!isArray &&    isPacked && supportPackedDoubles && Type.DOUBLE.equals(member.getType())) {
      return new PackedDoubleMapper(member);
    }
    else if (!isArray &&    isPacked && !supportPackedDoubles && Type.DOUBLE.equals(member.getType())) {
      System.err.println("WARNING: double packed is not supported");
      return new SimpleMapper(member, type);
    }
    else if (!isArray &&   !isPacked && Type.DOUBLE.equals(member.getType())) {
      return new SimpleMapper(member, type);
    }
    else if (!isArray &&    isPacked && supportPackedDoubles && Type.FLOAT.equals(member.getType())) {
      System.err.println("WARNING: float packed is not supported");
      return new SimpleMapper(member, type);
    }
    else if (!isArray &&    isPacked && !supportPackedDoubles && Type.FLOAT.equals(member.getType())) {
      System.err.println("WARNING: float packed is not supported");
      return new SimpleMapper(member, type);
    }
    else if (!isArray &&   !isPacked && Type.FLOAT.equals(member.getType())) {
      return new SimpleMapper(member, type);
    }
    else if (!isArray &&    isPacked && supportPackedDoubles && Type.COMPLEX.equals(member.getType())) {
      System.err.println("WARNING: complex packed is not supported");
      return new ComplexMapper(member, type);
    }
    else if (!isArray &&    isPacked && !supportPackedDoubles && Type.COMPLEX.equals(member.getType())) {
      System.err.println("WARNING: complex packed is not supported");
      return new ComplexMapper(member, type);
    }
    else if (!isArray &&   !isPacked && Type.COMPLEX.equals(member.getType())) {
      return new ComplexMapper(member, type);
    }
    else if (!isArray &&    isPacked && Type.SHORT.equals(member.getType()) && (((PackedMember) member).getRangeStart() != ((PackedMember) member).getRangeEnd())) {
      return new PackedMapper((PackedMember) member, type);
    }
    else if (!isArray &&    isPacked && Type.SHORT.equals(member.getType()) && (((PackedMember) member).getRangeStart() == ((PackedMember) member).getRangeEnd())) {
      System.err.println("WARNING: packed scope for short exceeds given range");
      return new SimpleMapper(member, type);
    }
    else if (!isArray &&   !isPacked && Type.SHORT.equals(member.getType()) ) {
      return new SimpleMapper(member, type);
    }
    else if (!isArray &&    isPacked && Type.INT.equals(member.getType()) && (((PackedMember) member).getRangeStart() != ((PackedMember) member).getRangeEnd())) {
      return new PackedMapper((PackedMember) member, type);
    }
    else if (!isArray &&    isPacked && Type.INT.equals(member.getType()) && (((PackedMember) member).getRangeStart() == ((PackedMember) member).getRangeEnd())) {
      System.err.println("WARNING: packed scope for int exceeds given range");
      return new SimpleMapper(member, type);
    }
    else if (!isArray &&   !isPacked && Type.INT.equals(member.getType()) ) {
      return new SimpleMapper(member, type);
    }
    else if (!isArray &&    isPacked && Type.LONG.equals(member.getType()) && (((PackedMember) member).getRangeStart() != ((PackedMember) member).getRangeEnd())) {
      return new PackedMapper((PackedMember) member, type);
    }
    else if (!isArray &&    isPacked && Type.LONG.equals(member.getType()) && (((PackedMember) member).getRangeStart() == ((PackedMember) member).getRangeEnd())) {
      System.err.println("WARNING: packed scope for long exceeds given range");
      return new SimpleMapper(member, type);
    }
    else if (!isArray &&   !isPacked && Type.LONG.equals(member.getType()) ) {
      return new SimpleMapper(member, type);
    }
    else if (!isArray &&    isPacked && Type.LONGLONG.equals(member.getType()) && (((PackedMember) member).getRangeStart() != ((PackedMember) member).getRangeEnd())) {
      return new PackedMapper((PackedMember) member, type);
    }
    else if (!isArray &&    isPacked && Type.LONGLONG.equals(member.getType()) && (((PackedMember) member).getRangeStart() == ((PackedMember) member).getRangeEnd())) {
      System.err.println("WARNING: packed scope for long long exceeds given range");
      return new SimpleMapper(member, type);
    }
    else if (!isArray &&   !isPacked && Type.LONGLONG.equals(member.getType()) ) {
      return new SimpleMapper(member, type);
    }
    else if (!isArray &&    isPacked && Type.POINTER.equals(member.getType()) && (((PackedMember) member).getRangeStart() != ((PackedMember) member).getRangeEnd())) {
      System.err.println("WARNING: packed pointer not supported");
      return new PointerMapper(member, type);
    }
    else if (!isArray &&    isPacked && Type.POINTER.equals(member.getType()) && (((PackedMember) member).getRangeStart() == ((PackedMember) member).getRangeEnd())) {
      System.err.println("WARNING: packed pointer not supported");
      return new PointerMapper(member, type);
    }
    else if (!isArray &&   !isPacked && Type.POINTER.equals(member.getType()) ) {
      return new PointerMapper(member, type);
    }
    else if (!isArray &&    isPacked && Type.BYTE.equals(member.getType()) && (((PackedMember) member).getRangeStart() != ((PackedMember) member).getRangeEnd())) {
      return new PackedMapper((PackedMember) member, type);
    }
    else if (!isArray &&    isPacked && Type.BYTE.equals(member.getType()) && (((PackedMember) member).getRangeStart() == ((PackedMember) member).getRangeEnd())) {
      System.err.println("WARNING: packed scope for byte (signed char) exceeds given range");
      return new SimpleMapper(member, type);
    }
    else if (!isArray &&   !isPacked && Type.BYTE.equals(member.getType()) ) {
      return new SimpleMapper(member, type);
    }
    else {
      System.err.println("ERROR: Unknown mapper. member=" + member.toString() + ", type=" + type.toString() );
      System.err.println("  isArray=" + isArray );
      System.err.println("  isPacked=" + isPacked );
      System.err.println("  is float=" + Type.FLOAT.equals(member.getType()) );
      System.exit(1);
    }
    return new SimpleMapper(member, type);
  }

  
  public static MapperFactory getInstance() {
    if (instance == null) {
      instance = new MapperFactory();
    }
    return instance;
  }
}
