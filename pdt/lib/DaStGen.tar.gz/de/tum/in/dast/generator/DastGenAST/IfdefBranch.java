// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

import java.util.Collection;

import de.tum.in.dast.generator.conditionset.Conditional;

public class IfdefBranch extends Ifdef implements AbstractNode {

	public IfdefBranch(Conditional condition) {
		super(condition);
	}
	
	public IfdefBranch(Collection<Conditional> conditions) {
		super(conditions);
	}

	@Override
	public void applyVisitor(Visitor visitor) {
		visitor.process(this);
	}
	
}
