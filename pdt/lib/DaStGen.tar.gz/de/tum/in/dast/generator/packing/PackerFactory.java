// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.packing;

public class PackerFactory {

	private static Packer packer;
	
	public static Packer getPacker() {
		if (packer == null) {
			//packer = new SimplePacker();
			packer = new FirstFitPacker();
		}
		return packer;
	}
	
}
