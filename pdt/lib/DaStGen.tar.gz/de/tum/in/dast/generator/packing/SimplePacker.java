// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.packing;

import java.util.List;

import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.memberSelection.BitfieldMember;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.memberSelection.PackedMember;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;

public class SimplePacker implements Packer {

	String packedRecords = 
		NameTranslatorFactory.getNameTranslator().getAttributeName(Packer.FIELD_PACKED_RECORDS);
	
	
	public void pack(List<Member> virtualMembers,
			List<Member> technicalMembers, Type bitfieldType) {
		
		BitfieldMember field = new BitfieldMember(packedRecords, bitfieldType.getTypeString(false));
		String offset = "0";
		
		for (Member member: virtualMembers) {
			if (member.isPacked() && !Type.DOUBLE.equals(member.getType())) {
				PackedMember m = (PackedMember) member;
				if ("0".equals(m.getBitfieldLength())) {
					System.err.println("XXX");
					System.err.println("XXX Warning: Member "+m.getType() + " "+m.getMemberName() + " declared packed without effect!");
					System.err.println("XXX");
					technicalMembers.add(m);
				} else {
					m.setMappedVariable(packedRecords);
					m.setStartIndex(offset);
					offset = offset + " + "+m.getBitfieldLength();  
					field.addMember(m);
				}
			} else {
				technicalMembers.add(member);
			}
		}
		
		if (field.getNumberMembers() > 0) {
			technicalMembers.add(field);
		}
		
	}


}
