// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator;

import java.util.Vector;


/**
 * This class is intended to hold the commandline parameters as well as the 
 * current state of the code generation process.
 * 
 * @author Wolfgang Eckhardt
 */
public class DaStConfiguration {
	
	// the path of the sourcefile
	private String source;
	// the path of the destinationdirectory
	private String target;
	
	private Vector<String> searchPath;
	
  // indicating if the #pragma-statement should be generated
	public static boolean generatePragmas;
  public static boolean manuallyAlign;
  public static boolean manuallyInline;

	private static DaStConfiguration instance = null;

	
	private DaStConfiguration(String source, String target, Vector<String> searchPath) {
		this.source = source;
		this.target = target;
		this.searchPath = searchPath;
	}
	
	public static void initialize(String source, String target, Vector<String> searchPath) {
		instance = new DaStConfiguration(source, target, searchPath);
	}
	
	public static DaStConfiguration getConfiguration() {
		return instance.clone();
	}
	
	public DaStConfiguration clone() {
		return new DaStConfiguration(source, target, (Vector<String>)searchPath.clone());
	}
	
	public String getSource() {
		return source;
	}
	
	public String getTarget() {
		return target;
	}

	public Vector<String> getSearchPaths() {
	  return searchPath;
	}
  
}

