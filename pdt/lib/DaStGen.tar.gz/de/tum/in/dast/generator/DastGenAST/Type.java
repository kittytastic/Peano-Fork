// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

/**
 * Represents a type. This can be either a base type, like "int", "bool", etc...
 * or any other type like enum or class.
 * 
 * @author eckhardw
 *
 */
public class Type {
	
  /**
   * Keywords from SableCC grammar
   */
	public static String BOOL    = "bool";
	public static String INT     = "int";
	public static String LONG    = "long long int";
	public static String DOUBLE  = "double";
	public static String SHORT   = "short int";
	public static String BYTE    = "signed char";
  public static String COMPLEX = "complex";
  public static String FLOAT   = "float";
	
	
	private String type;
	
	private String qualification;

	private Size size;
	
	/**
	 * construct a new type.
	 * 
	 * @param type the type described by a string
	 * @param qualification empty string for basic types, otherwise the qualification, i.e. the namespace
	 */
	public Type(String type, String qualification) {
		this.type = type;
		this.qualification = qualification;
	}
	
	
	public Type(Type otherType) {
		this(otherType.type, otherType.qualification);
	}
	
	public Type getInnerType() {
		return new Type(this);
	}
	
	
	public String getTypeString(boolean qualified) {
		if (qualified && !"".equals(qualification)) {
			return qualification + "::" + type;
		}
		return type;
	}
	
	public void setSize(Size size) {
		this.size = size;
	}
	
	public Size getSize() {
		return size;
	}
	
	
	public boolean needsInitialization() {
		return false;
	}
	
	public String getInitialization(String fieldName) {
		throw new RuntimeException("Method should not be called! check for needsInitialization()!");
	}
	
	/**
	 * Returns the MPI_Datatype, the type is mapped to.  
	 * 
	 * @param type the String representing the type, e.g. "int"
	 */
	public static String getMPIType(String type, boolean isArray) {
		if (INT.equals(type)) {
			return "MPI_INT";
		} else if (SHORT.equals(type)) {
			return "MPI_SHORT";
    } else if (COMPLEX.equals(type)) {
      return "MPI_DOUBLE";
    } else if (FLOAT.equals(type)) {
      return "MPI_FLOAT";
		} else if (LONG.equals(type)) {
			return "MPI_LONG_LONG_INT";
		} else if (DOUBLE.equals(type)) {
			return "MPI_DOUBLE";
		} else if (BOOL.equals(type)) {
/*			if (isArray) {
				return "MPI_INT";
			} else {
			    return "MPI_CHAR";
			}*/
			return "MPI_CXX_BOOL";
		} else if (BYTE.equals(type)) {
				return "MPI_BYTE";
		} else {
			return "MPI_INT";
		}
	}
	
	
	/**
	 * TODO 
	 */
	public boolean isEnum() {
		return isEnum(type);
	}

	public static boolean isEnum(String type) {
		return (!BOOL.equals(type) &&
					!INT.equals(type) &&
					!DOUBLE.equals(type) &&
					!LONG.equals(type) &&
          !SHORT.equals(type) &&
          !FLOAT.equals(type) &&
          !COMPLEX.equals(type) &&
					!BYTE.equals(type));
	}


	public String getQualification() {
		return qualification;
	}
	
	public String toString() {
		return "type: " + qualification + "::" + type + " " + size;
	}
	
	@Override
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof Type)) {
			return false;
		}
		
		Type otherType = (Type) other;
		if (!this.qualification.equals(otherType.qualification)) {
			return false;
		}
		if (!this.type.equals(otherType.type)) {
			return false;
		}
		
		if (this.size == null) {
			if (otherType.size != null) {
				return false;
			}
		} else {
			return this.size.equals(otherType.size);
		}
		
		return true;
	}

}
