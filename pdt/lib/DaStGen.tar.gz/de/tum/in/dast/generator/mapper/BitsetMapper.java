// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.mapper;

import de.tum.in.dast.generator.DaStConfiguration;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.naming.StdBitsetType;
import de.tum.in.dast.util.DaStStringBuilder;

public class BitsetMapper extends ArrayMapper {

	public BitsetMapper(Member member) {
		super(member, new StdBitsetType("bool", "", member.getArraySize().getStringRepresentation()));
	}
	
	public int getNumberOfOperations() {
		return 5;
	}

	public void writeMethodSignature(int operationNumber, DaStStringBuilder builder) {
		switch (operationNumber) {
		case 4:
			writeMethodComment(builder);
			writeFlipOperationSignature(false,builder);
			builder.append( ";" );
			break;
		default: super.writeMethodSignature(operationNumber,builder);
		}
	}

	public void writeMethodImplementation(int operationNumber, DaStStringBuilder builder) {
		switch (operationNumber) {
		case 4:
			writeFlipOperationImplementation(builder);
			break;
		default: super.writeMethodImplementation(operationNumber,builder);
		}
	}
	
	
	protected void writeFlipOperationSignature(boolean qualified, DaStStringBuilder builder) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
	  if (qualified) {
      qualifiedClassName = member.getClassName() + "::";
    }
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
	  builder.append( prefix + " void " + qualifiedClassName + translator.getBitArrayFlipOperationName(member.getMemberName()) + "(int elementIndex) " + attributes );
	}
	

	protected void writeFlipOperationImplementation(DaStStringBuilder builder) {
      String mappedUnpackedVariable = member.getMappedVariable();
	  builder.indent();
      writeFlipOperationSignature(!DaStConfiguration.manuallyInline,builder);
      builder.append( " {" );
      builder.incrementAndIndent(getClass().getName());
      writeElementAccessAssertions(builder);
      builder.append( mappedUnpackedVariable );
      builder.append(".flip(elementIndex);");
      builder.decrementAndIndent(getClass().getName());
      
      builder.appendAndIndent("}");
	}
	

}
